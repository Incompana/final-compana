const pool = require('../config/database');
const { validate: isUuid } = require('uuid');

// ======================
// CREATE JOB
// ======================
const addJob = async (data) => {
  const {
    company_id,
    category_id,
    title,
    description,

    job_type = 'full-time',
    experience_level = 'mid',
    location_type = 'onsite',

    location_city = null,

    salary_min = 0,
    salary_max = 0,

    is_salary_visible = true,
    status = 'open',
  } = data;

  const result = await pool.query(
    `
    INSERT INTO jobs (
      id,
      company_id,
      category_id,
      title,
      description,
      job_type,
      experience_level,
      location_type,
      location_city,
      salary_min,
      salary_max,
      is_salary_visible,
      status,
      created_at
    )
    VALUES (
      gen_random_uuid(),
      $1,
      $2,
      $3,
      $4,
      $5,
      $6,
      $7,
      $8,
      $9,
      $10,
      $11,
      $12,
      NOW()
    )
    RETURNING *
    `,
    [
      company_id,
      category_id,
      title,
      description,
      job_type,
      experience_level,
      location_type,
      location_city,
      salary_min,
      salary_max,
      is_salary_visible,
      status,
    ]
  );

  return result.rows[0];
};

// ======================
// GET ALL JOBS
// ======================
const getJobs = async (query) => {
  const { title, 'company-name': companyName } = query;

  let sql = `
    SELECT
      jobs.id,
      jobs.company_id,
      jobs.category_id,
      jobs.title,
      jobs.description,
      jobs.job_type,
      jobs.experience_level,
      jobs.location_type,
      jobs.location_city,
      jobs.salary_min,
      jobs.salary_max,
      jobs.status,
      companies.name AS company_name
    FROM jobs
    JOIN companies
      ON companies.id = jobs.company_id
    WHERE 1=1
  `;

  const values = [];
  let index = 1;

  if (title) {
    sql += ` AND jobs.title ILIKE $${index++}`;
    values.push(`%${title}%`);
  }

  if (companyName) {
    sql += ` AND companies.name ILIKE $${index++}`;
    values.push(`%${companyName}%`);
  }

  const result = await pool.query(sql, values);

  return result.rows;
};

// ======================
// GET JOB BY ID
// ======================
const getJobById = async (id) => {
  if (!isUuid(id)) {
    return null;
  }

  const result = await pool.query(
    `
    SELECT
      jobs.*,
      companies.name AS company_name
    FROM jobs
    JOIN companies
      ON companies.id = jobs.company_id
    WHERE jobs.id = $1
    `,
    [id]
  );

  return result.rows[0] || null;
};

// ======================
// UPDATE JOB
// ======================
const updateJob = async (id, data) => {
  if (!isUuid(id)) {
    return null;
  }

  const fields = [];
  const values = [];
  let index = 1;

  Object.keys(data).forEach((key) => {
    fields.push(`${key}=$${index++}`);
    values.push(data[key]);
  });

  values.push(id);

  const result = await pool.query(
    `
    UPDATE jobs
    SET ${fields.join(', ')}
    WHERE id=$${index}
    RETURNING *
    `,
    values
  );

  return result.rows[0] || null;
};

// ======================
// DELETE JOB
// ======================
const deleteJob = async (id) => {
  if (!isUuid(id)) {
    return null;
  }

  const result = await pool.query(
    `
    DELETE FROM jobs
    WHERE id=$1
    RETURNING *
    `,
    [id]
  );

  return result.rows[0] || null;
};
// ======================
// GET JOBS BY COMPANY
// ======================
const getJobsByCompany = async (companyId) => {
  const result = await pool.query(
    `
    SELECT
      jobs.id,
      jobs.company_id,
      jobs.category_id,
      jobs.title,
      jobs.description,
      jobs.job_type,
      jobs.experience_level,
      jobs.location_type,
      jobs.location_city,
      jobs.salary_min,
      jobs.salary_max,
      jobs.is_salary_visible,
      jobs.status
    FROM jobs
    JOIN companies
      ON companies.id = jobs.company_id
    WHERE jobs.company_id = $1
    `,
    [companyId]
  );

  return result.rows;
};

// ======================
// GET JOBS BY CATEGORY
// ======================
const getJobsByCategory = async (categoryId) => {
  if (!isUuid(categoryId)) {
    return [];
  }

  const result = await pool.query(
    `
    SELECT *
    FROM jobs
    WHERE category_id=$1
    `,
    [categoryId]
  );

  return result.rows;
};

module.exports = {
  addJob,
  getJobs,
  getJobById,
  updateJob,
  deleteJob,
  getJobsByCompany,
  getJobsByCategory,
};