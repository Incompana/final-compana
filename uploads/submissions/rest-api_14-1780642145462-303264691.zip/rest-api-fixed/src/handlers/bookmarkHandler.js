const bookmarkService = require('../services/bookmarkService');

const respond = (res, { status, message, data }, code) => {
  const body = { status, ...(message && { message }), ...(data && { data }) };
  return res.status(code).json(body);
};

const createBookmarkHandler = async (req, res) => {
  try {
    const { id: user_id } = req.auth.credentials;
    const { jobId: job_id } = req.params;
    const bookmark = await bookmarkService.createBookmark({ user_id, job_id });
    return respond(res, { status: 'success', message: 'Bookmark berhasil ditambahkan', data: bookmark }, 201);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getBookmarkByIdHandler = async (req, res) => {
  try {
    const bookmark = await bookmarkService.getBookmarkById(req.params.id);
    return respond(res, { status: 'success', data: bookmark }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const deleteBookmarkHandler = async (req, res) => {
  try {
    const { id: user_id } = req.auth.credentials;
    const { jobId: job_id } = req.params;
    await bookmarkService.deleteBookmarkByUserAndJob({ user_id, job_id });
    return respond(res, { status: 'success', message: 'Bookmark berhasil dihapus' }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getAllBookmarksHandler = async (req, res) => {
  try {
    const { id: user_id } = req.auth.credentials;
    const bookmarks = await bookmarkService.getAllBookmarksByUserId(user_id);
    return respond(res, { status: 'success', data: { bookmarks } }, 200);
  } catch (err) {
    return respond(res, { status: 'error', message: err.message }, 500);
  }
};

module.exports = { createBookmarkHandler, getBookmarkByIdHandler, deleteBookmarkHandler, getAllBookmarksHandler };
