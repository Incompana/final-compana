const companyService = require('../services/companyService');
const RedisService = require('../services/redisService');
const { CompanySchema } = require('../validations/companyValidation');

// CREATE
const createCompany = async (req, res, next) => {
  try {
    const { error } = CompanySchema.validate(req.body);
    if (error) throw error;

    const company = await companyService.createCompany({
      ...req.body,
      owner_id: req.userId,
    });

    return res.status(201).json({
      status: 'success',
      data: company,
    });
  } catch (err) {
    next(err);
  }
};

// GET ALL
const getCompanies = async (req, res, next) => {
  try {
    const companies = await companyService.getCompanies();

    return res.status(200).json({
      status: 'success',
      data: {
        companies,
      },
    });
  } catch (err) {
    next(err);
  }
};

// GET BY ID (CACHE OK)
const getCompanyById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const cacheKey = `company:${id}`;

    const cached = await RedisService.get(cacheKey);

    if (cached) {
      return res
        .header('X-Data-Source', 'cache')
        .status(200)
        .json({
          status: 'success',
          data: JSON.parse(cached),
        });
    }

    const company = await companyService.getCompanyById(id);

    await RedisService.set(cacheKey, JSON.stringify(company), 3600);

    return res
      .header('X-Data-Source', 'database')
      .status(200)
      .json({
        status: 'success',
        data: company,
      });
  } catch (err) {
    next(err);
  }
};

// UPDATE
const updateCompany = async (req, res, next) => {
  try {
    const company = await companyService.updateCompany(
      req.params.id,
      req.body
    );

    await RedisService.del(`company:${req.params.id}`);

    return res.status(200).json({
      status: 'success',
      message: 'Company updated successfully',
      data: company,
    });
  } catch (err) {
    next(err);
  }
};

// DELETE
const deleteCompany = async (req, res, next) => {
  try {
    await companyService.deleteCompany(req.params.id);

    await RedisService.del(`company:${req.params.id}`);

    return res.status(200).json({
      status: 'success',
      message: 'Company deleted successfully',
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  createCompany,
  getCompanies,
  getCompanyById,
  updateCompany,
  deleteCompany,
};