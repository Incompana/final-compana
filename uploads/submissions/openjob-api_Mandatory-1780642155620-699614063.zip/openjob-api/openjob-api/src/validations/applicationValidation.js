const Joi = require('joi');

const applicationSchema = Joi.object({
  user_id: Joi.string().required(),

  job_id: Joi.string().required(),

  cover_letter: Joi.string().required(),

  resume_url: Joi.string().required(),

  status: Joi.string()
    .valid('pending', 'reviewed', 'accepted', 'rejected')
    .optional(),
});

module.exports = applicationSchema;