require('dotenv').config();

const amqp = require('amqplib');

const amqpUrl = require('./config/rabbitmq');
const handleApplicationCreated = require('./service/consumerService');

const queue = 'applications';

const startConsumer = async () => {
  try {
    const connection = await amqp.connect(amqpUrl);

    const channel = await connection.createChannel();

    await channel.assertQueue(queue, {
      durable: true,
    });

    console.log('Consumer berjalan...');

    channel.consume(queue, async (message) => {
      const data = JSON.parse(
        message.content.toString()
      );

      console.log(
        'Message diterima:',
        data
      );

      await handleApplicationCreated(
        data.application_id
      );

      channel.ack(message);
    });

  } catch (error) {
    console.log(error);
  }
};

startConsumer();