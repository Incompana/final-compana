exports.up = (pgm) => {
  pgm.createTable('documents', {
    id: {
      type: 'VARCHAR(50)',
      primaryKey: true,
    },

    user_id: {
      type: 'VARCHAR(50)',
      notNull: true,
      references: 'users(id)',
      onDelete: 'CASCADE',
    },

    filename: {
      type: 'TEXT',
      notNull: true,
    },

    filepath: {
      type: 'TEXT',
      notNull: true,
    },

    original_name: {
      type: 'TEXT',
      notNull: true,
    },

    size: {
      type: 'INTEGER',
      notNull: true,
    },

    created_at: {
      type: 'TIMESTAMP',
      default: pgm.func('current_timestamp'),
    },
  });
};

exports.down = (pgm) => {
  pgm.dropTable('documents');
};