const pool = require('../config/database');
const bcrypt = require('bcrypt');
const { nanoid } = require('nanoid');

const addUser = async ({ name, email, password, role }) => {
  const id = `user-${nanoid(16)}`;

  const hashedPassword = await bcrypt.hash(password, 10);

  await pool.query(
    `
    INSERT INTO users (id, name, email, password, role)
    VALUES ($1, $2, $3, $4, $5)
    `,
    [id, name, email, hashedPassword, role || 'user']
  );

  // 🔥 IMPORTANT: jangan ambil dari DB lagi, langsung return sesuai test
  return {
    id,
    name,
    email,
  };
};

const getUsers = async () => {
  const result = await pool.query(`
    SELECT id, name, email FROM users
  `);

  return result.rows;
};

const getUserById = async (id) => {
  const result = await pool.query(
    `
    SELECT id, name, email FROM users WHERE id = $1
  `,
    [id]
  );

  if (!result.rows.length) {
    const error = new Error('User not found');
    error.statusCode = 404;
    throw error;
  }

  return result.rows[0];
};

module.exports = {
  addUser,
  getUsers,
  getUserById,
};