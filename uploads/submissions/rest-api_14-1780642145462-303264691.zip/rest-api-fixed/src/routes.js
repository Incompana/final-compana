const { Router } = require('express');
const multer = require('multer');
const path = require('path');
const { authenticate } = require('./middleware/auth');
const { validationMiddleware } = require('./middleware/validation');

const { validateUserPayload } = require('./validators/userValidator');
const { validateLoginPayload, validateRefreshToken } = require('./validators/authenticationValidator');
const { validateCreateCompany, validateUpdateCompany } = require('./validators/companyValidator');
const { validateCreateCategory, validateUpdateCategory, validateCreateJob, validateUpdateJob, validateCreateApplication, validateUpdateApplication } = require('./validators/otherValidators');

const { createUserHandler, getUserByIdHandler } = require('./handlers/userHandler');
const { loginHandler, refreshTokenHandler, logoutHandler } = require('./handlers/authenticationHandler');
const { createCompanyHandler, getAllCompaniesHandler, getCompanyByIdHandler, updateCompanyHandler, deleteCompanyHandler } = require('./handlers/companyHandler');
const { createCategoryHandler, getAllCategoriesHandler, getCategoryByIdHandler, updateCategoryHandler, deleteCategoryHandler } = require('./handlers/categoryHandler');
const { createJobHandler, getAllJobsHandler, getJobByIdHandler, getJobsByCompanyHandler, getJobsByCategoryHandler, updateJobHandler, deleteJobHandler } = require('./handlers/jobHandler');
const { createApplicationHandler, getAllApplicationsHandler, getApplicationByIdHandler, getApplicationsByUserHandler, getApplicationsByJobHandler, updateApplicationHandler, deleteApplicationHandler } = require('./handlers/applicationHandler');
const { createBookmarkHandler, getBookmarkByIdHandler, deleteBookmarkHandler, getAllBookmarksHandler } = require('./handlers/bookmarkHandler');
const { uploadDocumentHandler, getAllDocumentsHandler, getDocumentByIdHandler, deleteDocumentHandler } = require('./handlers/documentHandler');
const { getProfileHandler, getMyApplicationsHandler, getMyBookmarksHandler } = require('./handlers/profileHandler');

// Multer config for document uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads');
    require('fs').mkdirSync(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}_${file.originalname}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

const router = Router();

// Validator middleware
const validateUser = validationMiddleware(validateUserPayload);
const validateLogin = validationMiddleware(validateLoginPayload);
const validateRefresh = validationMiddleware(validateRefreshToken);
const validateCreateCompanyMiddleware = validationMiddleware(validateCreateCompany);
const validateUpdateCompanyMiddleware = validationMiddleware(validateUpdateCompany);
const validateCreateCategoryMiddleware = validationMiddleware(validateCreateCategory);
const validateUpdateCategoryMiddleware = validationMiddleware(validateUpdateCategory);
const validateCreateJobMiddleware = validationMiddleware(validateCreateJob);
const validateUpdateJobMiddleware = validationMiddleware(validateUpdateJob);
const validateCreateApplicationMiddleware = validationMiddleware(validateCreateApplication);
const validateUpdateApplicationMiddleware = validationMiddleware(validateUpdateApplication);

// ── PUBLIC: Users ──────────────────────────────────────────────────────────
router.post('/users', validateUser, createUserHandler);
router.get('/users/:id', getUserByIdHandler);

// ── PUBLIC: Authentications ────────────────────────────────────────────────
router.post('/authentications', validateLogin, loginHandler);
router.put('/authentications', validateRefresh, refreshTokenHandler);
router.delete('/authentications', authenticate, validateRefresh, logoutHandler);

// ── PUBLIC: Companies ──────────────────────────────────────────────────────
router.get('/companies', getAllCompaniesHandler);
router.get('/companies/:id', getCompanyByIdHandler);

// ── PROTECTED: Companies ───────────────────────────────────────────────────
router.post('/companies', authenticate, validateCreateCompanyMiddleware, createCompanyHandler);
router.put('/companies/:id', authenticate, validateUpdateCompanyMiddleware, updateCompanyHandler);
router.delete('/companies/:id', authenticate, deleteCompanyHandler);

// ── PUBLIC: Categories ─────────────────────────────────────────────────────
router.get('/categories', getAllCategoriesHandler);
router.get('/categories/:id', getCategoryByIdHandler);

// ── PROTECTED: Categories ──────────────────────────────────────────────────
router.post('/categories', authenticate, validateCreateCategoryMiddleware, createCategoryHandler);
router.put('/categories/:id', authenticate, validateUpdateCategoryMiddleware, updateCategoryHandler);
router.delete('/categories/:id', authenticate, deleteCategoryHandler);

// ── PUBLIC: Jobs ───────────────────────────────────────────────────────────
router.get('/jobs', getAllJobsHandler);
router.get('/jobs/company/:companyId', getJobsByCompanyHandler);
router.get('/jobs/category/:categoryId', getJobsByCategoryHandler);
router.get('/jobs/:id', getJobByIdHandler);

// ── PROTECTED: Jobs ────────────────────────────────────────────────────────
router.post('/jobs', authenticate, validateCreateJobMiddleware, createJobHandler);
router.put('/jobs/:id', authenticate, validateUpdateJobMiddleware, updateJobHandler);
router.delete('/jobs/:id', authenticate, deleteJobHandler);

// ── PROTECTED: Applications ────────────────────────────────────────────────
router.post('/applications', authenticate, validateCreateApplicationMiddleware, createApplicationHandler);
router.get('/applications', authenticate, getAllApplicationsHandler);
router.get('/applications/user/:userId', authenticate, getApplicationsByUserHandler);
router.get('/applications/job/:jobId', authenticate, getApplicationsByJobHandler);
router.get('/applications/:id', authenticate, getApplicationByIdHandler);
router.put('/applications/:id', authenticate, validateUpdateApplicationMiddleware, updateApplicationHandler);
router.delete('/applications/:id', authenticate, deleteApplicationHandler);

// ── PROTECTED: Bookmarks ───────────────────────────────────────────────────
router.post('/jobs/:jobId/bookmark', authenticate, createBookmarkHandler);
router.get('/jobs/:jobId/bookmark/:id', authenticate, getBookmarkByIdHandler);
router.delete('/jobs/:jobId/bookmark', authenticate, deleteBookmarkHandler);
router.get('/bookmarks', authenticate, getAllBookmarksHandler);

// ── PUBLIC: Documents ──────────────────────────────────────────────────────
router.get('/documents', getAllDocumentsHandler);
router.get('/documents/:id', getDocumentByIdHandler);

// ── PROTECTED: Documents ───────────────────────────────────────────────────
router.post('/documents', authenticate, upload.single('document'), uploadDocumentHandler);
router.delete('/documents/:id', authenticate, deleteDocumentHandler);

// ── PROTECTED: Profile ─────────────────────────────────────────────────────
router.get('/profile', authenticate, getProfileHandler);
router.get('/profile/applications', authenticate, getMyApplicationsHandler);
router.get('/profile/bookmarks', authenticate, getMyBookmarksHandler);

module.exports = router;
