const express = require('express');
const jwt = require('jsonwebtoken');

const router = express.Router();

const validate = require('../middleware/validate');
const authSchema = require('../validations/authValidation');

const {
  verifyUser,
  addRefreshToken,
  checkRefreshToken,
  deleteRefreshToken,
} = require('../services/authService');

const {
  generateAccessToken,
  generateRefreshToken,
} = require('../utils/token');


// LOGIN
router.post('/', validate(authSchema), async (req, res, next) => {
  try {
    const { email, password } = req.body;

    const user = await verifyUser(email, password);

    const accessToken = generateAccessToken({ id: user.id });
    const refreshToken = generateRefreshToken({ id: user.id });

    await addRefreshToken(refreshToken);

    return res.status(200).json({
      status: 'success',
      data: {
        accessToken,
        refreshToken,
      },
    });
  } catch (err) {
    next(err);
  }
});


// REFRESH TOKEN
router.put('/', async (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(400).json({
      status: 'failed',
      message: 'Refresh token is required',
    });
  }

  const isValid = await checkRefreshToken(refreshToken);

  if (!isValid) {
    return res.status(400).json({
      status: 'failed',
      message: 'Invalid refresh token',
    });
  }

  try {
    const decoded = jwt.verify(
      refreshToken,
      process.env.REFRESH_TOKEN_KEY
    );

    const accessToken = generateAccessToken({
      id: decoded.id,
    });

    return res.status(200).json({
      status: 'success',
      data: {
        accessToken,
      },
    });
  } catch (err) {
    return res.status(400).json({
      status: 'failed',
      message: 'Invalid refresh token',
    });
  }
});


// DELETE / LOGOUT
router.delete('/', async (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(400).json({
      status: 'failed',
      message: 'Refresh token is required',
    });
  }

  const isValid = await checkRefreshToken(refreshToken);

  if (!isValid) {
    return res.status(400).json({
      status: 'failed',
      message: 'Invalid refresh token',
    });
  }

  await deleteRefreshToken(refreshToken);

  return res.status(200).json({
    status: 'success',
    message: 'Logged out successfully',
  });
});

module.exports = router;