/** @type {import('eslint').Linter.FlatConfig[]} */
module.exports = [
  {
    // File yang dicakup ESLint
    files: ['src/**/*.js', 'migrations/**/*.js'],

    // Abaikan folder tertentu
    ignores: ['node_modules/**', 'uploads/**'],

    languageOptions: {
      ecmaVersion: 2020,
      sourceType: 'commonjs',
      globals: {
        // Node.js globals
        require: 'readonly',
        module: 'readonly',
        exports: 'readonly',
        __dirname: 'readonly',
        __filename: 'readonly',
        process: 'readonly',
        console: 'readonly',
      },
    },

    rules: {
      // ── Kemungkinan Error ──────────────────────────────────────────────────
      'no-undef': 'error',             // Larang variabel yang tidak dideklarasikan
      'no-unused-vars': ['warn', {        // Peringatkan variabel yang tidak dipakai
        argsIgnorePattern: '^_',          // Kecuali parameter diawali _
        varsIgnorePattern: '^_',          // Kecuali variabel diawali _
        caughtErrorsIgnorePattern: '^_',  // Kecuali catch error diawali _
      }],
      'no-console': 'warn',            // Peringatkan penggunaan console.*
      'no-duplicate-case': 'error',    // Larang case duplikat di switch
      'no-empty': 'error',             // Larang blok kode kosong
      'no-extra-semi': 'error',        // Larang titik koma berlebih
      'no-unreachable': 'error',       // Larang kode setelah return/throw

      // ── Praktik Terbaik ───────────────────────────────────────────────────
      'eqeqeq': ['error', 'always'],   // Wajib === bukan ==
      'no-var': 'error',               // Larang var, gunakan const/let
      'prefer-const': ['error', {      // Wajib const jika tidak di-reassign
        destructuring: 'any',
        ignoreReadBeforeAssign: false,
      }],
      'no-throw-literal': 'error',     // Hanya boleh throw Error object
      'no-return-await': 'error',      // Larang return await yang tidak perlu
      'consistent-return': 'error',    // Konsistensikan return value dalam fungsi
      'curly': ['error', 'all'],       // Wajib kurung kurawal di semua blok if/else

      // ── Gaya Penulisan (Style) ─────────────────────────────────────────────
      'semi': ['error', 'always'],             // Wajib titik koma
      'quotes': ['error', 'single', {          // Wajib single quote
        avoidEscape: true,
        allowTemplateLiterals: false,
      }],
      'indent': ['error', 2, {                 // Indentasi 2 spasi
        SwitchCase: 1,
      }],
      'comma-dangle': ['error', 'always-multiline'], // Trailing comma di multiline
      'comma-spacing': ['error', {             // Spasi setelah koma
        before: false,
        after: true,
      }],
      'key-spacing': ['error', {               // Spasi pada key objek
        beforeColon: false,
        afterColon: true,
      }],
      'space-before-blocks': 'error',          // Spasi sebelum { blok
      'space-before-function-paren': ['error', { // Spasi sebelum () fungsi
        anonymous: 'never',
        named: 'never',
        asyncArrow: 'always',
      }],
      'space-infix-ops': 'error',              // Spasi di operator (=, +, dll)
      'keyword-spacing': ['error', {           // Spasi setelah keyword (if, for, dll)
        before: true,
        after: true,
      }],
      'object-curly-spacing': ['error', 'always'],  // Spasi dalam { objek }
      'array-bracket-spacing': ['error', 'never'],  // Tanpa spasi dalam [array]
      'space-in-parens': ['error', 'never'],         // Tanpa spasi dalam (paren)
      'no-trailing-spaces': 'error',           // Tanpa spasi di akhir baris
      'no-multiple-empty-lines': ['error', {   // Maksimal 1 baris kosong
        max: 1,
        maxEOF: 0,
      }],
      'eol-last': ['error', 'always'],         // Newline di akhir file
      'arrow-spacing': ['error', {             // Spasi di arrow function =>
        before: true,
        after: true,
      }],
      'arrow-parens': ['error', 'always'],     // Wajib () di arrow function
      'no-multi-spaces': 'error',              // Larang spasi ganda
    },
  },
];
