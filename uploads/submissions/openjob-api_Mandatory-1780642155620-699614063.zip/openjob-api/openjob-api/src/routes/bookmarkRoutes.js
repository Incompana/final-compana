const router = require('express').Router();

const auth = require('../middleware/auth');

const {
  postBookmark,
  getBookmarks,
  getBookmarkById,
  deleteBookmark,
} = require('../controllers/bookmarkController');

// ADD BOOKMARK
router.post(
  '/jobs/:id/bookmark',
  auth,
  postBookmark
);

// GET ALL BOOKMARKS
router.get(
  '/',
  auth,
  getBookmarks
);

// GET BOOKMARK BY ID
router.get(
  '/jobs/:id/bookmark/:bookmarkId',
  auth,
  getBookmarkById
);

// DELETE BOOKMARK
router.delete(
  '/jobs/:id/bookmark',
  auth,
  deleteBookmark
);

module.exports = router;