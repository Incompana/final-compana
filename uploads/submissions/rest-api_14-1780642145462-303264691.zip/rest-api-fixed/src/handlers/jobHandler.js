const jobService = require('../services/jobService');
const companyService = require('../services/companyService');

const respond = (res, { status, message, data }, code) => {
  const body = { status, ...(message && { message }), ...(data && { data }) };
  return res.status(code).json(body);
};

const createJobHandler = async (req, res) => {
  try {
    const { id: userId } = req.auth.credentials;
    await companyService.verifyCompanyOwner(req.body.company_id, userId);

    const { job_type, location_type, location_city, ...rest } = req.body;
    const location = location_type === 'remote' ? 'remote' : location_city;
    const jobPayload = {
      ...rest,
      type: job_type,
      location,
    };

    const job = await jobService.createJob(jobPayload);
    return respond(res, { status: 'success', message: 'Job berhasil ditambahkan', data: job }, 201);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getAllJobsHandler = async (req, res) => {
  try {
    const { title, company_name: companyName } = req.query;
    const jobs = await jobService.getAllJobs({ title, companyName });
    return respond(res, { status: 'success', data: { jobs } }, 200);
  } catch (err) {
    return respond(res, { status: 'error', message: err.message }, 500);
  }
};

const getJobByIdHandler = async (req, res) => {
  try {
    const job = await jobService.getJobById(req.params.id);
    return respond(res, { status: 'success', data: job }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getJobsByCompanyHandler = async (req, res) => {
  try {
    const jobs = await jobService.getJobsByCompanyId(req.params.companyId);
    return respond(res, { status: 'success', data: { jobs } }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getJobsByCategoryHandler = async (req, res) => {
  try {
    const jobs = await jobService.getJobsByCategoryId(req.params.categoryId);
    return respond(res, { status: 'success', data: { jobs } }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const updateJobHandler = async (req, res) => {
  try {
    const { id: userId } = req.auth.credentials;
    const { id } = req.params;
    await jobService.verifyJobOwner(id, userId);

    const { job_type, location_type, location_city, ...rest } = req.body;
    const location = location_type === 'remote' ? 'remote' : location_city;
    const jobPayload = {
      ...rest,
      ...(job_type !== undefined && { type: job_type }),
      ...(location_type !== undefined || location_city !== undefined ? { location } : {}),
    };

    const job = await jobService.updateJobById(id, jobPayload);
    return respond(res, { status: 'success', message: 'Job berhasil diperbarui', data: job }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const deleteJobHandler = async (req, res) => {
  try {
    const { id: userId } = req.auth.credentials;
    const { id } = req.params;
    await jobService.verifyJobOwner(id, userId);
    await jobService.deleteJobById(id);
    return respond(res, { status: 'success', message: 'Job berhasil dihapus' }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

module.exports = { createJobHandler, getAllJobsHandler, getJobByIdHandler, getJobsByCompanyHandler, getJobsByCategoryHandler, updateJobHandler, deleteJobHandler };
