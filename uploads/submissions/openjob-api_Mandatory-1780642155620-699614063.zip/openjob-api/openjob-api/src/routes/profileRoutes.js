const express = require('express');

const router = express.Router();

const auth = require('../middleware/auth');

const pool = require('../config/database');

router.get(
  '/',
  auth,
  async (req, res, next) => {
    try {
      const result = await pool.query(
        `
        SELECT id, name, email
        FROM users
        WHERE id = $1
      `,
        [req.user.id]
      );

      res.json({
        status: 'success',
        data: result.rows[0],
      });
    } catch (error) {
      next(error);
    }
  }
);

router.get(
  '/applications',
  auth,
  async (req, res, next) => {
    try {
      const result = await pool.query(
        `
        SELECT applications.*, jobs.title
        FROM applications
        JOIN jobs
          ON applications.job_id = jobs.id
        WHERE applications.user_id = $1
      `,
        [req.user.id]
      );

      res.json({
        status: 'success',
        data: result.rows,
      });
    } catch (error) {
      next(error);
    }
  }
);

router.get(
  '/bookmarks',
  auth,
  async (req, res, next) => {
    try {
      const result = await pool.query(
        `
        SELECT bookmarks.*, jobs.title
        FROM bookmarks
        JOIN jobs
          ON bookmarks.job_id = jobs.id
        WHERE bookmarks.user_id = $1
      `,
        [req.user.id]
      );

      res.json({
        status: 'success',
        data: result.rows,
      });
    } catch (error) {
      next(error);
    }
  }
);

module.exports = router;