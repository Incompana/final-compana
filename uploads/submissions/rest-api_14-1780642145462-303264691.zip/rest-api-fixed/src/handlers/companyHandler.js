const companyService = require('../services/companyService');

const respond = (res, { status, message, data }, code) => {
  const body = { status, ...(message && { message }), ...(data && { data }) };
  return res.status(code).json(body);
};

const createCompanyHandler = async (req, res) => {
  try {
    const { id: owner_id } = req.auth.credentials;
    const company = await companyService.createCompany({ ...req.body, owner_id });
    return respond(res, { status: 'success', message: 'Company berhasil ditambahkan', data: company }, 201);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getAllCompaniesHandler = async (req, res) => {
  try {
    const companies = await companyService.getAllCompanies();
    return respond(res, { status: 'success', data: { companies } }, 200);
  } catch (err) {
    return respond(res, { status: 'error', message: err.message }, 500);
  }
};

const getCompanyByIdHandler = async (req, res) => {
  try {
    const company = await companyService.getCompanyById(req.params.id);
    return respond(res, { status: 'success', data: company }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const updateCompanyHandler = async (req, res) => {
  try {
    const { id: userId } = req.auth.credentials;
    const { id } = req.params;
    // Pastikan company ada dulu, jika tidak ada akan melempar NotFoundError (404)
    await companyService.getCompanyById(id);
    await companyService.verifyCompanyOwner(id, userId);
    const company = await companyService.updateCompanyById(id, req.body);
    return respond(res, { status: 'success', message: 'Company berhasil diperbarui', data: company }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const deleteCompanyHandler = async (req, res) => {
  try {
    const { id: userId } = req.auth.credentials;
    const { id } = req.params;
    await companyService.verifyCompanyOwner(id, userId);
    await companyService.deleteCompanyById(id);
    return respond(res, { status: 'success', message: 'Company berhasil dihapus' }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

module.exports = { createCompanyHandler, getAllCompaniesHandler, getCompanyByIdHandler, updateCompanyHandler, deleteCompanyHandler };
