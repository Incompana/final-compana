const pool = require('../config/database');


// CREATE
const addCategory = async (data) => {

  const result = await pool.query(
    `
      INSERT INTO categories (
        id,
        name,
        created_at,
        updated_at
      )
      VALUES (
        gen_random_uuid(),
        $1,
        NOW(),
        NOW()
      )
      RETURNING *
    `,
    [data.name]
  );

  return result.rows[0];
};


// GET ALL
const getCategories = async () => {

  const result = await pool.query(`
    SELECT *
    FROM categories
    ORDER BY created_at DESC
  `);

  return result.rows;
};


// GET BY ID
const getCategoryById = async (id) => {

  const result = await pool.query(
    `
      SELECT *
      FROM categories
      WHERE id = $1
    `,
    [id]
  );

  return result.rows[0];
};


// UPDATE
const updateCategory = async (
  id,
  data
) => {

  const result = await pool.query(
    `
      UPDATE categories
      SET
        name = $1,
        updated_at = NOW()
      WHERE id = $2
      RETURNING *
    `,
    [data.name, id]
  );

  return result.rows[0];
};


// DELETE
const deleteCategory = async (id) => {

  const result = await pool.query(
    `
      DELETE FROM categories
      WHERE id = $1
      RETURNING *
    `,
    [id]
  );

  return result.rows[0];
};


module.exports = {
  addCategory,
  getCategories,
  getCategoryById,
  updateCategory,
  deleteCategory,
};