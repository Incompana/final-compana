const pool = require('../config/database');
const { nanoid } = require('nanoid');

// ======================
// ADD BOOKMARK
// ======================
const addBookmark = async (userId, jobId) => {
  const id = `bookmark-${nanoid(16)}`;

  const result = await pool.query(
    `
    INSERT INTO bookmarks (
      id,
      user_id,
      job_id
    )
    VALUES ($1, $2, $3)
    RETURNING *
    `,
    [id, userId, jobId]
  );

  return result.rows[0];
};

// ======================
// GET ALL BOOKMARKS
// ======================
const getBookmarks = async (userId) => {
  const result = await pool.query(
    `
    SELECT
      b.id,
      b.user_id,
      b.job_id,

      j.company_id,
      j.category_id,
      j.title,
      j.description,
      j.job_type,
      j.experience_level,
      j.location_type,
      j.location_city,
      j.salary_min,
      j.salary_max,
      j.is_salary_visible,
      j.status,
      j.created_at,
      j.updated_at,

      c.name AS company_name

    FROM bookmarks b
    JOIN jobs j
      ON j.id = b.job_id

    LEFT JOIN companies c
      ON c.id = j.company_id

    WHERE b.user_id = $1
    `,
    [userId]
  );

  return result.rows.map((r) => ({
    id: r.id,
    user_id: r.user_id,
    job_id: r.job_id,

    company_id: r.company_id,
    category_id: r.category_id,

    title: r.title,
    description: r.description,

    job_type: r.job_type,
    experience_level: r.experience_level,

    location_type: r.location_type,
    location_city: r.location_city,

    salary_min: r.salary_min,
    salary_max: r.salary_max,

    is_salary_visible: r.is_salary_visible,

    status: r.status,

    created_at: r.created_at,
    updated_at: r.updated_at,

    company_name: r.company_name,
  }));
};

// ======================
// GET BOOKMARK BY ID
// ======================
const getBookmarkById = async (id) => {
  const result = await pool.query(
    `
    SELECT *
    FROM bookmarks
    WHERE id = $1
    `,
    [id]
  );

  return result.rows[0] || null;
};

// ======================
// DELETE BOOKMARK
// ======================
const deleteBookmark = async (userId, jobId) => {
  const result = await pool.query(
    `
    DELETE FROM bookmarks
    WHERE user_id = $1
      AND job_id = $2
    RETURNING *
    `,
    [userId, jobId]
  );

  return result.rows[0] || null;
};

module.exports = {
  addBookmark,
  getBookmarks,
  getBookmarkById,
  deleteBookmark,
};