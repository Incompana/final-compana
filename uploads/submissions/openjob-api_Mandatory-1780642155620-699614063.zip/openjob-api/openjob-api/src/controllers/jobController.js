const service = require('../services/jobService');
const jobSchema = require('../validations/jobValidation');

const success = (res, data, code = 200) => {
  return res.status(code).json({
    status: 'success',
    data,
  });
};

const failed = (res, message, code = 400) => {
  return res.status(code).json({
    status: 'failed',
    message,
  });
};

// ======================
// CREATE JOB
// ======================
const postJob = async (req, res) => {
  try {
    const { error } = jobSchema.validate(req.body);

    if (error) {
      return failed(res, error.details[0].message, 400);
    }

    const job = await service.addJob(req.body);

    return success(
      res,
      {
        id: job.id,
      },
      201
    );
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

// ======================
// GET ALL JOBS
// ======================
const getJobs = async (req, res) => {
  try {
    const jobs = await service.getJobs(req.query);

    return success(res, {
      jobs,
    });
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

// ======================
// GET JOB BY ID
// ======================
const getJobById = async (req, res) => {
  try {
    const job = await service.getJobById(req.params.id);

    if (!job) {
      return failed(res, 'Job not found', 404);
    }

    return success(res, job);
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

// ======================
// UPDATE JOB
// ======================
const putJob = async (req, res) => {
  try {
    const job = await service.updateJob(req.params.id, req.body);

    if (!job) {
      return failed(res, 'Job not found', 404);
    }

    return res.status(200).json({
      status: 'success',
      message: 'Job updated successfully',
      data: job,
    });
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

// ======================
// DELETE JOB
// ======================
const deleteJob = async (req, res) => {
  try {
    const job = await service.deleteJob(req.params.id);

    if (!job) {
      return failed(res, 'Job not found', 404);
    }

    return res.status(200).json({
      status: 'success',
      message: 'Job deleted',
    });
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

// ======================
// GET JOB BY COMPANY
// ======================
const getByCompany = async (req, res) => {
  try {
    const jobs = await service.getJobsByCompany(req.params.id);

    return success(res, {
      jobs,
    });
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

// ======================
// GET JOB BY CATEGORY
// ======================
const getByCategory = async (req, res) => {
  try {
    const jobs = await service.getJobsByCategory(req.params.id);

    return success(res, {
      jobs,
    });
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

module.exports = {
  postJob,
  getJobs,
  getJobById,
  putJob,
  deleteJob,
  getByCompany,
  getByCategory,
};