const errorHandler = (err, req, res, next) => {
  console.error(err);

  // default
  let statusCode = err.statusCode || 500;
  let message = err.message || 'Internal Server Error';

  // Joi validation
  if (err.isJoi) {
    statusCode = 400;
    message = err.details[0].message;
  }

  // invalid UUID / format id
  if (err.code === '22P02') {
    statusCode = 404;
    message = 'Not found';
  }

  // foreign key error
  if (err.code === '23503') {
    statusCode = 404;
    message = 'Not found';
  }

  return res.status(statusCode).json({
    status: 'failed',
    message,
  });
};

module.exports = errorHandler;