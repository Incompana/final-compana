exports.up = (pgm) => {
  pgm.createTable('users', {
    id: {
      type: 'VARCHAR(50)',
      primaryKey: true,
    },

    name: {
      type: 'VARCHAR(100)',
      notNull: true,
    },

    email: {
      type: 'VARCHAR(100)',
      unique: true,
      notNull: true,
    },

    password: {
      type: 'TEXT',
      notNull: true,
    },

    role: {
      type: 'VARCHAR(50)',
      notNull: true,
      default: 'user',
    },

    created_at: {
      type: 'TIMESTAMP',
      default: pgm.func('current_timestamp'),
    },

    updated_at: {
      type: 'TIMESTAMP',
      default: pgm.func('current_timestamp'),
    },
  });
};

exports.down = (pgm) => {
  pgm.dropTable('users');
};