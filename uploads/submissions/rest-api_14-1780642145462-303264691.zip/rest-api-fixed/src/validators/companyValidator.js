const Joi = require('joi');
const { ValidationError } = require('../exceptions');

const CreateCompanySchema = Joi.object({
  name: Joi.string().min(1).max(100).required(),
  description: Joi.string().min(1).max(1000).required(),
  industry: Joi.string().max(100).allow('', null),
  location: Joi.string().min(1).max(100).required(),
  website: Joi.string().uri().max(255).allow('', null),
  logo_url: Joi.string().allow('', null),
}).unknown(false);

const UpdateCompanySchema = Joi.object({
  name: Joi.string().min(1).max(100).required(),
  description: Joi.string().min(1).max(1000).required(),
  industry: Joi.string().max(100).allow('', null),
  location: Joi.string().min(1).max(100).required(),
  website: Joi.string().uri().max(255).allow('', null),
  logo_url: Joi.string().allow('', null),
}).unknown(false);

const validateCreateCompany = (payload) => {
  const { error } = CreateCompanySchema.validate(payload);
  if (error) {throw new ValidationError(error.message);}
};

const validateUpdateCompany = (payload) => {
  const { error } = UpdateCompanySchema.validate(payload);
  if (error) {throw new ValidationError(error.message);}
};

module.exports = { validateCreateCompany, validateUpdateCompany };
