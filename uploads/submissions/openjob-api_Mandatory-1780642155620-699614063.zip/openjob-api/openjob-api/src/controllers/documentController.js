const fs = require('fs');
const path = require('path');
const service = require('../services/documentService');

const uploadDocument = async (req, res) => {
  try {
    console.log('USER ID:', req.userId);
    console.log('FILE:', req.file);

    // ❗ FIX WAJIB
    if (!req.file) {
      return res.status(400).json({
        status: 'failed',
        message: 'File is required (upload PDF with key: document)',
      });
    }

    if (!req.userId) {
      return res.status(401).json({
        status: 'failed',
        message: 'Unauthorized',
      });
    }

    const document = await service.addDocument(
      req.userId,
      req.file.filename,
      req.file.path,
      req.file.originalname,
      req.file.size
    );

    return res.status(201).json({
      status: 'success',
      data: {
        documentId: document.id,
        filename: document.filename,
        originalName: document.original_name,
        size: document.size,
      },
    });
  } catch (err) {
    console.log('ERROR:', err);

    return res.status(400).json({
      status: 'failed',
      message: err.message,
    });
  }
};
const getDocuments = async (req, res) => {
  const documents = await service.getDocuments();

  return res.status(200).json({
    status: 'success',
    data: { documents },
  });
};

const getDocumentById = async (req, res) => {
  const document = await service.getDocumentById(req.params.id);

  if (!document) {
    return res.status(404).json({
      status: 'failed',
      message: 'Document not found',
    });
  }

  return res.download(
    path.resolve(document.filepath),
    document.original_name
  );
};

const deleteDocument = async (req, res) => {
  const document = await service.deleteDocument(req.params.id);

  if (!document) {
    return res.status(404).json({
      status: 'failed',
      message: 'Document not found',
    });
  }

  const filePath = path.resolve(document.filepath);

  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }

  return res.status(200).json({
    status: 'success',
    message: 'Document deleted',
  });
};

module.exports = {
  uploadDocument,
  getDocuments,
  getDocumentById,
  deleteDocument,
};