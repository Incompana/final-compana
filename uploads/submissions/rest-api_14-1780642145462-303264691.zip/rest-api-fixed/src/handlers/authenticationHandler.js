const userService = require('../services/userService');
const authService = require('../services/authenticationService');
const TokenManager = require('../tokenize/TokenManager');

const respond = (res, { status, message, data }, code) => {
  const body = { status, ...(message && { message }), ...(data && { data }) };
  return res.status(code).json(body);
};

const loginHandler = async (req, res) => {
  try {
    const { email, password } = req.body;
    const userId = await userService.verifyUserCredential(email, password);
    const accessToken = TokenManager.generateAccessToken({ id: userId });
    const refreshToken = TokenManager.generateRefreshToken({ id: userId });
    await authService.addRefreshToken(refreshToken);
    return respond(res, { status: 'success', message: 'Login berhasil', data: { accessToken, refreshToken } }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const refreshTokenHandler = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    const payload = TokenManager.verifyRefreshToken(refreshToken);
    await authService.verifyRefreshToken(refreshToken);
    const accessToken = TokenManager.generateAccessToken({ id: payload.id });
    return respond(res, { status: 'success', message: 'Access token berhasil diperbarui', data: { accessToken } }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const logoutHandler = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    await authService.verifyRefreshToken(refreshToken);
    await authService.deleteRefreshToken(refreshToken);
    return respond(res, { status: 'success', message: 'Logout berhasil' }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

module.exports = { loginHandler, refreshTokenHandler, logoutHandler };
