const pool = require('../config/database');

// CREATE APPLICATION
const addApplication = async (data) => {
  const {
    user_id,
    job_id,
    cover_letter = '',
    resume_url = '',
    status = 'pending',
  } = data;

  // CHECK JOB EXISTS
  const checkJob = await pool.query(
    `
    SELECT * FROM jobs
    WHERE id=$1
    `,
    [job_id]
  );

  if (!checkJob.rows.length) {
    throw new Error('Job not found');
  }

  // CHECK DUPLICATE
  const checkApplication = await pool.query(
    `
    SELECT * FROM applications
    WHERE user_id=$1 AND job_id=$2
    `,
    [user_id, job_id]
  );

  if (checkApplication.rows.length) {
    throw new Error('Application already exists');
  }

  const id = `application-${Date.now()}`;

  const result = await pool.query(
    `
    INSERT INTO applications (
      id,
      user_id,
      job_id,
      cover_letter,
      resume_url,
      status,
      created_at
    )
    VALUES ($1,$2,$3,$4,$5,$6,NOW())
    RETURNING *
    `,
    [
      id,
      user_id,
      job_id,
      cover_letter,
      resume_url,
      status,
    ]
  );

  return result.rows[0];
};

// FORMAT DATA
const formatApplication = (app) => ({
  ...app,

  company_name: null,
  job_title: null,
  applicant_name: null,
  applicant_email: null,
  updated_at: null,
  deleted_at: null,
});

// GET ALL
const getApplications = async () => {
  const result = await pool.query(`
    SELECT *
    FROM applications
    ORDER BY created_at DESC
  `);

  return result.rows.map(formatApplication);
};

// GET BY ID
const getApplicationById = async (id) => {
  const result = await pool.query(
    `
    SELECT *
    FROM applications
    WHERE id=$1
    `,
    [id]
  );

  if (!result.rows[0]) {
    return null;
  }

  return formatApplication(result.rows[0]);
};

// GET BY USER
const getApplicationsByUser = async (userId) => {
  const result = await pool.query(
    `
    SELECT *
    FROM applications
    WHERE user_id=$1
    `,
    [userId]
  );

  return result.rows.map(formatApplication);
};

// GET BY JOB
const getApplicationsByJob = async (jobId) => {
  const result = await pool.query(
    `
    SELECT *
    FROM applications
    WHERE job_id=$1
    `,
    [jobId]
  );

  return result.rows.map(formatApplication);
};

// UPDATE STATUS
const updateApplication = async (id, status) => {
  const result = await pool.query(
    `
    UPDATE applications
    SET status=$1
    WHERE id=$2
    RETURNING *
    `,
    [status, id]
  );

  if (!result.rows[0]) {
    return null;
  }

  return formatApplication(result.rows[0]);
};

// DELETE
const deleteApplication = async (id) => {
  const result = await pool.query(
    `
    DELETE FROM applications
    WHERE id=$1
    RETURNING *
    `,
    [id]
  );

  return result.rows[0] || null;
};

module.exports = {
  addApplication,
  getApplications,
  getApplicationById,
  getApplicationsByUser,
  getApplicationsByJob,
  updateApplication,
  deleteApplication,
};