const bcrypt = require('bcrypt');
const pool = require('../db/pool');
const { randomBytes } = require('crypto');
const { NotFoundError, ConflictError, AuthenticationError } = require('../exceptions');

const createUser = async ({ name, email, password, role = 'user' }) => {
  const checkEmail = await pool.query({ text: 'SELECT id FROM users WHERE email = $1', values: [email] });
  if (checkEmail.rows.length > 0) {throw new ConflictError('Email sudah digunakan');}

  const id = `user-${randomBytes(12).toString('base64url')}`;
  const hashedPassword = await bcrypt.hash(password, 10);
  const now = new Date().toISOString();

  const result = await pool.query({
    text: `INSERT INTO users (id, name, email, password, role, created_at, updated_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
           RETURNING id, name, email, role, created_at, updated_at`,
    values: [id, name, email, hashedPassword, role, now, now],
  });
  const user = result.rows[0];
  return {
    ...user,
    username: user.email,
    fullname: user.name,
  };
};

const getUserById = async (id) => {
  const result = await pool.query({
    text: 'SELECT id, name, email, role, created_at, updated_at FROM users WHERE id = $1',
    values: [id],
  });
  if (result.rows.length === 0) {throw new NotFoundError(`User dengan id ${id} tidak ditemukan`);}
  const user = result.rows[0];
  return {
    ...user,
    username: user.email,
    fullname: user.name,
  };
};

const verifyUserCredential = async (email, password) => {
  const result = await pool.query({ text: 'SELECT id, password FROM users WHERE email = $1', values: [email] });
  if (result.rows.length === 0) {throw new AuthenticationError('Kredensial yang Anda berikan salah');}

  const { id, password: hashedPassword } = result.rows[0];
  const match = await bcrypt.compare(password, hashedPassword);
  if (!match) {throw new AuthenticationError('Kredensial yang Anda berikan salah');}
  return id;
};

module.exports = { createUser, getUserById, verifyUserCredential };
