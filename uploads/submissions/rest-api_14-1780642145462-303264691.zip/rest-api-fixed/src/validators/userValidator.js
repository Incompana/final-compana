const Joi = require('joi');
const { ValidationError } = require('../exceptions');

const UserPayloadSchema = Joi.object({
  name: Joi.string().min(1).max(100).required(),
  email: Joi.string().email().max(100).required(),
  password: Joi.string().min(8).required(),
  role: Joi.string().valid('user', 'admin', 'company').default('user'),
}).unknown(false);

const validateUserPayload = (payload) => {
  const { error, value } = UserPayloadSchema.validate(payload, { abortEarly: false });
  if (error) { throw new ValidationError(error.message); }
  return value;
};

module.exports = { validateUserPayload };
