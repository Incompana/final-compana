const documentService = require('../services/documentService');

const respond = (res, { status, message, data }, code) => {
  const body = { status, ...(message && { message }), ...(data && { data }) };
  return res.status(code).json(body);
};

const uploadDocumentHandler = async (req, res) => {
  try {
    const { id: user_id } = req.auth.credentials;

    if (!req.file) {
      return respond(res, { status: 'failed', message: 'File document wajib diupload' }, 400);
    }

    const file_url = `/uploads/${req.file.filename}`;
    const file_type = req.file.mimetype;
    const file_size = req.file.size;
    const name = req.file.originalname;

    const doc = await documentService.createDocument({ user_id, name, file_url, file_type, file_size });
    return respond(res, { status: 'success', message: 'Document berhasil diupload', data: doc }, 201);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getAllDocumentsHandler = async (req, res) => {
  try {
    const documents = await documentService.getAllDocuments();
    return respond(res, { status: 'success', data: { documents } }, 200);
  } catch (err) {
    return respond(res, { status: 'error', message: err.message }, 500);
  }
};

const getDocumentByIdHandler = async (req, res) => {
  try {
    const document = await documentService.getDocumentById(req.params.id);
    return respond(res, { status: 'success', data: document }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const deleteDocumentHandler = async (req, res) => {
  try {
    const { id: userId } = req.auth.credentials;
    await documentService.verifyDocumentOwner(req.params.id, userId);
    await documentService.deleteDocumentById(req.params.id);
    return respond(res, { status: 'success', message: 'Document berhasil dihapus' }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

module.exports = { uploadDocumentHandler, getAllDocumentsHandler, getDocumentByIdHandler, deleteDocumentHandler };
