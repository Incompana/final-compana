const service = require('../services/applicationService');
const RedisService = require('../services/redisService');
const publishMessage = require('../services/rabbitmqService');

const success = (res, data, code = 200) =>
  res.status(code).json({
    status: 'success',
    data,
  });

const failed = (res, message, code = 400) =>
  res.status(code).json({
    status: 'failed',
    message,
  });

// APPLY JOB
const applyJob = async (req, res) => {
  try {
    const application = await service.addApplication(req.body);

    // PUBLISH RABBITMQ
    await publishMessage('applications', {
      application_id: application.id,
    });

    // DELETE CACHE
    await RedisService.del(
      `applications:user:${req.body.user_id}`
    );

    await RedisService.del(
      `applications:job:${req.body.job_id}`
    );

    return success(res, application, 201);

  } catch (err) {
    return failed(res, err.message);
  }
};

// GET ALL
const getApplications = async (req, res) => {
  try {
    const applications = await service.getApplications();

    return success(res, {
      applications,
    });

  } catch (err) {
    return failed(res, err.message);
  }
};

// GET BY ID
const getApplicationById = async (req, res) => {
  try {
    const { id } = req.params;

    const cacheKey = `application:${id}`;

    const cachedData = await RedisService.get(cacheKey);

    // CACHE HIT
    if (cachedData) {
      return res
        .header('X-Data-Source', 'cache')
        .json({
          status: 'success',
          data: JSON.parse(cachedData),
        });
    }

    // DATABASE
    const application =
      await service.getApplicationById(id);

    if (!application) {
      return failed(
        res,
        'Application not found',
        404
      );
    }

    // SAVE CACHE
    await RedisService.set(
      cacheKey,
      JSON.stringify(application),
      3600
    );

    return res
      .header('X-Data-Source', 'database')
      .json({
        status: 'success',
        data: application,
      });

  } catch (err) {
    return failed(res, err.message);
  }
};

// GET BY USER
const getApplicationsByUser = async (req, res) => {
  try {
    const { userId } = req.params;

    const cacheKey =
      `applications:user:${userId}`;

    const cachedData =
      await RedisService.get(cacheKey);

    // CACHE HIT
    if (cachedData) {
      return res
        .header('X-Data-Source', 'cache')
        .json({
          status: 'success',
          data: {
            applications:
              JSON.parse(cachedData),
          },
        });
    }

    // DATABASE
    const applications =
      await service.getApplicationsByUser(
        userId
      );

    // SAVE CACHE
    await RedisService.set(
      cacheKey,
      JSON.stringify(applications),
      3600
    );

    return res
      .header('X-Data-Source', 'database')
      .json({
        status: 'success',
        data: {
          applications,
        },
      });

  } catch (err) {
    return failed(res, err.message);
  }
};

// GET BY JOB
const getApplicationsByJob = async (req, res) => {
  try {
    const { jobId } = req.params;

    const cacheKey =
      `applications:job:${jobId}`;

    const cachedData =
      await RedisService.get(cacheKey);

    // CACHE HIT
    if (cachedData) {
      return res
        .header('X-Data-Source', 'cache')
        .json({
          status: 'success',
          data: {
            applications:
              JSON.parse(cachedData),
          },
        });
    }

    // DATABASE
    const applications =
      await service.getApplicationsByJob(
        jobId
      );

    // SAVE CACHE
    await RedisService.set(
      cacheKey,
      JSON.stringify(applications),
      3600
    );

    return res
      .header('X-Data-Source', 'database')
      .json({
        status: 'success',
        data: {
          applications,
        },
      });

  } catch (err) {
    return failed(res, err.message);
  }
};

// UPDATE
const updateApplication = async (req, res) => {
  try {
    const oldApplication =
      await service.getApplicationById(
        req.params.id
      );

    if (!oldApplication) {
      return failed(
        res,
        'Application not found',
        404
      );
    }

    const application =
      await service.updateApplication(
        req.params.id,
        req.body.status
      );

    // DELETE CACHE
    await RedisService.del(
      `application:${req.params.id}`
    );

    await RedisService.del(
      `applications:user:${oldApplication.user_id}`
    );

    await RedisService.del(
      `applications:job:${oldApplication.job_id}`
    );

    return res.status(200).json({
      status: 'success',
      message:
        'Application updated successfully',
      data: application,
    });

  } catch (err) {
    return failed(res, err.message);
  }
};

// DELETE
const deleteApplication = async (req, res) => {
  try {
    const oldApplication =
      await service.getApplicationById(
        req.params.id
      );

    if (!oldApplication) {
      return failed(
        res,
        'Application not found',
        404
      );
    }

    await service.deleteApplication(
      req.params.id
    );

    // DELETE CACHE
    await RedisService.del(
      `application:${req.params.id}`
    );

    await RedisService.del(
      `applications:user:${oldApplication.user_id}`
    );

    await RedisService.del(
      `applications:job:${oldApplication.job_id}`
    );

    return success(res, {
      message: 'Application deleted',
    });

  } catch (err) {
    return failed(res, err.message);
  }
};

module.exports = {
  applyJob,
  getApplications,
  getApplicationById,
  getApplicationsByUser,
  getApplicationsByJob,
  updateApplication,
  deleteApplication,
};