const userService = require('../services/userService');

const respond = (res, { status, message, data }, code) => {
  const body = { status, ...(message && { message }), ...(data && { data }) };
  return res.status(code).json(body);
};

const createUserHandler = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const user = await userService.createUser({ name, email, password, role });
    return respond(res, { status: 'success', message: 'User berhasil ditambahkan', data: user }, 201);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getUserByIdHandler = async (req, res) => {
  try {
    const user = await userService.getUserById(req.params.id);
    return respond(res, { status: 'success', data: user }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

module.exports = { createUserHandler, getUserByIdHandler };
