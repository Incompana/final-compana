const handleApplicationCreated =
  async (applicationId) => {

    console.log(
      'Application diterima:',
      applicationId
    );

};

module.exports =
  handleApplicationCreated;