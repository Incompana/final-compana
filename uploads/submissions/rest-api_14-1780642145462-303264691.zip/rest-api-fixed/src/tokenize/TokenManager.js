require('dotenv').config();
const jwt = require('jsonwebtoken');
const { AuthenticationError, ValidationError } = require('../exceptions');

const TokenManager = {
  generateAccessToken: (payload) => jwt.sign(
    payload,
    process.env.ACCESS_TOKEN_KEY,
    { expiresIn: parseInt(process.env.ACCESS_TOKEN_AGE, 10) || 1800 },
  ),

  generateRefreshToken: (payload) => jwt.sign(
    payload,
    process.env.REFRESH_TOKEN_KEY,
  ),

  verifyAccessToken: (token) => {
    try {
      return jwt.verify(token, process.env.ACCESS_TOKEN_KEY);
    } catch {
      throw new AuthenticationError('Access token tidak valid');
    }
  },

  verifyRefreshToken: (refreshToken) => {
    try {
      return jwt.verify(refreshToken, process.env.REFRESH_TOKEN_KEY);
    } catch {
      throw new ValidationError('Refresh token tidak valid');
    }
  },
};

module.exports = TokenManager;
