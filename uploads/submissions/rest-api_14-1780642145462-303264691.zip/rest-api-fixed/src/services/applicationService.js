const pool = require('../db/pool');
const { randomBytes } = require('crypto');
const { NotFoundError, AuthorizationError, ConflictError } = require('../exceptions');

const createApplication = async ({ user_id, job_id, cover_letter }) => {
  const jobCheck = await pool.query({ text: 'SELECT id FROM jobs WHERE id = $1', values: [job_id] });
  if (jobCheck.rows.length === 0) {
    throw new NotFoundError(`Job dengan id ${job_id} tidak ditemukan`);
  }

  const check = await pool.query({
    text: 'SELECT id FROM applications WHERE user_id = $1 AND job_id = $2',
    values: [user_id, job_id],
  });
  if (check.rows.length > 0) {throw new ConflictError('Anda sudah melamar pekerjaan ini');}

  const id = `app-${randomBytes(12).toString('base64url')}`;
  const now = new Date().toISOString();
  const result = await pool.query({
    text: `INSERT INTO applications (id, user_id, job_id, cover_letter, status, created_at, updated_at)
           VALUES ($1,$2,$3,$4,'pending',$5,$6) RETURNING *`,
    values: [id, user_id, job_id, cover_letter, now, now],
  });
  return result.rows[0];
};

const getAllApplications = async () => {
  const result = await pool.query(`
    SELECT a.*, u.email as username, u.name as fullname, j.title as job_title
    FROM applications a
    JOIN users u ON a.user_id = u.id
    JOIN jobs j ON a.job_id = j.id
    ORDER BY a.created_at DESC
  `);
  return result.rows;
};

const getApplicationById = async (id) => {
  const result = await pool.query({
    text: `SELECT a.*, u.email as username, u.name as fullname, j.title as job_title
           FROM applications a
           JOIN users u ON a.user_id = u.id
           JOIN jobs j ON a.job_id = j.id
           WHERE a.id = $1`,
    values: [id],
  });
  if (result.rows.length === 0) {throw new NotFoundError(`Application dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const getApplicationsByUserId = async (userId) => {
  const result = await pool.query({
    text: `SELECT a.*, j.title as job_title, c.name as company_name
           FROM applications a
           JOIN jobs j ON a.job_id = j.id
           JOIN companies c ON j.company_id = c.id
           WHERE a.user_id = $1 ORDER BY a.created_at DESC`,
    values: [userId],
  });
  return result.rows;
};

const getApplicationsByJobId = async (jobId) => {
  const result = await pool.query({
    text: `SELECT a.*, u.email as username, u.name as fullname
           FROM applications a
           JOIN users u ON a.user_id = u.id
           WHERE a.job_id = $1 ORDER BY a.created_at DESC`,
    values: [jobId],
  });
  return result.rows;
};

const updateApplicationById = async (id, { status }) => {
  const now = new Date().toISOString();
  const result = await pool.query({
    text: 'UPDATE applications SET status = $1, updated_at = $2 WHERE id = $3 RETURNING *',
    values: [status, now, id],
  });
  if (result.rows.length === 0) {throw new NotFoundError(`Application dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const deleteApplicationById = async (id) => {
  const result = await pool.query({ text: 'DELETE FROM applications WHERE id = $1 RETURNING id', values: [id] });
  if (result.rows.length === 0) {throw new NotFoundError(`Application dengan id ${id} tidak ditemukan`);}
};

const verifyApplicationAccess = async (applicationId, userId) => {
  const result = await pool.query({ text: 'SELECT user_id FROM applications WHERE id = $1', values: [applicationId] });
  if (result.rows.length === 0) {throw new NotFoundError(`Application dengan id ${applicationId} tidak ditemukan`);}
  if (result.rows[0].user_id !== userId) {throw new AuthorizationError('Anda tidak berhak mengakses resource ini');}
};

module.exports = {
  createApplication, getAllApplications, getApplicationById,
  getApplicationsByUserId, getApplicationsByJobId,
  updateApplicationById, deleteApplicationById, verifyApplicationAccess,
};
