const pool = require('../db/pool');
const { randomBytes } = require('crypto');
const { NotFoundError, ConflictError } = require('../exceptions');

const createCategory = async ({ name, description }) => {
  const check = await pool.query({ text: 'SELECT id FROM categories WHERE name = $1', values: [name] });
  if (check.rows.length > 0) {throw new ConflictError('Nama kategori sudah digunakan');}

  const id = `category-${randomBytes(12).toString('base64url')}`;
  const now = new Date().toISOString();
  const result = await pool.query({
    text: 'INSERT INTO categories (id, name, description, created_at, updated_at) VALUES ($1,$2,$3,$4,$5) RETURNING *',
    values: [id, name, description, now, now],
  });
  return result.rows[0];
};

const getAllCategories = async () => {
  const result = await pool.query('SELECT * FROM categories ORDER BY name ASC');
  return result.rows;
};

const getCategoryById = async (id) => {
  const result = await pool.query({ text: 'SELECT * FROM categories WHERE id = $1', values: [id] });
  if (result.rows.length === 0) {throw new NotFoundError(`Category dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const updateCategoryById = async (id, { name, description }) => {
  const fields = [];
  const values = [];
  let idx = 1;
  if (name !== undefined) { fields.push(`name = $${idx++}`); values.push(name); }
  if (description !== undefined) { fields.push(`description = $${idx++}`); values.push(description); }
  fields.push(`updated_at = $${idx++}`);
  values.push(new Date().toISOString());
  values.push(id);
  const result = await pool.query({
    text: `UPDATE categories SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`,
    values,
  });
  if (result.rows.length === 0) {throw new NotFoundError(`Category dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const deleteCategoryById = async (id) => {
  const result = await pool.query({ text: 'DELETE FROM categories WHERE id = $1 RETURNING id', values: [id] });
  if (result.rows.length === 0) {throw new NotFoundError(`Category dengan id ${id} tidak ditemukan`);}
};

module.exports = { createCategory, getAllCategories, getCategoryById, updateCategoryById, deleteCategoryById };
