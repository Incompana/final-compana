const Joi = require('joi');
const { ValidationError } = require('../exceptions');

// ── Category ──────────────────────────────────────────────────────────────────
const CreateCategorySchema = Joi.object({
  name: Joi.string().min(1).max(100).required(),
  description: Joi.string().allow('', null),
}).unknown(false);
const UpdateCategorySchema = Joi.object({
  name: Joi.string().max(100),
  description: Joi.string().allow('', null),
}).min(1).unknown(false);

const validateCreateCategory = (payload) => {
  const { error, value } = CreateCategorySchema.validate(payload, { abortEarly: false });
  if (error) { throw new ValidationError(error.message); }
  return value;
};
const validateUpdateCategory = (payload) => {
  const { error, value } = UpdateCategorySchema.validate(payload, { abortEarly: false });
  if (error) { throw new ValidationError(error.message); }
  return value;
};

// ── Job ───────────────────────────────────────────────────────────────────────
const CreateJobSchema = Joi.object({
  company_id: Joi.string().min(1).required(),
  category_id: Joi.string().min(1).required(),
  title: Joi.string().min(1).max(200).required(),
  description: Joi.string().min(1).required(),
  job_type: Joi.string().max(50).required(),
  experience_level: Joi.string().max(50).required(),
  location_type: Joi.string().max(50).required(),
  location_city: Joi.string().min(1).max(100).allow('', null),
  salary_min: Joi.number().integer().min(0).optional(),
  salary_max: Joi.number().integer().min(0).optional(),
  is_salary_visible: Joi.boolean().optional(),
  status: Joi.string().valid('open', 'closed', 'draft').required(),
  requirements: Joi.string().allow('', null).optional(),
}).unknown(false);
const UpdateJobSchema = Joi.object({
  company_id: Joi.string().min(1),
  category_id: Joi.string().min(1),
  title: Joi.string().min(1).max(200),
  description: Joi.string().allow('', null),
  job_type: Joi.string().max(50),
  experience_level: Joi.string().max(50),
  location_type: Joi.string().max(50),
  location_city: Joi.string().max(100),
  salary_min: Joi.number().integer().min(0),
  salary_max: Joi.number().integer().min(0),
  is_salary_visible: Joi.boolean(),
  status: Joi.string().valid('open', 'closed', 'draft'),
  requirements: Joi.string().allow('', null),
}).min(1).unknown(false);

const validateCreateJob = (payload) => {
  const { error, value } = CreateJobSchema.validate(payload, { abortEarly: false });
  if (error) { throw new ValidationError(error.message); }
  return value;
};
const validateUpdateJob = (payload) => {
  const { error, value } = UpdateJobSchema.validate(payload, { abortEarly: false });
  if (error) { throw new ValidationError(error.message); }
  return value;
};

// ── Application ───────────────────────────────────────────────────────────────
const CreateApplicationSchema = Joi.object({
  user_id: Joi.string().min(1),
  job_id: Joi.string(),
  jobId: Joi.string(),
  status: Joi.string().valid('pending', 'reviewed', 'accepted', 'rejected'),
  cover_letter: Joi.string().allow('', null),
  coverLetter: Joi.string().allow('', null),
})
  .or('job_id', 'jobId')
  .unknown(false);
const UpdateApplicationSchema = Joi.object({
  status: Joi.string().valid('pending', 'reviewed', 'accepted', 'rejected').required(),
}).unknown(false);

const validateCreateApplication = (payload) => {
  const { error, value } = CreateApplicationSchema.validate(payload, { abortEarly: false });
  if (error) { throw new ValidationError(error.message); }
  return value;
};
const validateUpdateApplication = (payload) => {
  const { error, value } = UpdateApplicationSchema.validate(payload, { abortEarly: false });
  if (error) { throw new ValidationError(error.message); }
  return value;
};

module.exports = {
  validateCreateCategory, validateUpdateCategory,
  validateCreateJob, validateUpdateJob,
  validateCreateApplication, validateUpdateApplication,
};
