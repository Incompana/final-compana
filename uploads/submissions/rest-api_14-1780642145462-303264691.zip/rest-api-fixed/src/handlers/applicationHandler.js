const appService = require('../services/applicationService');

const respond = (res, { status, message, data }, code) => {
  const body = { status, ...(message && { message }), ...(data && { data }) };
  return res.status(code).json(body);
};

const createApplicationHandler = async (req, res) => {
  try {
    const { id: user_id } = req.auth.credentials;
    const { job_id, jobId, cover_letter, coverLetter } = req.body;
    const normalized = {
      user_id,
      job_id: job_id || jobId,
      cover_letter: cover_letter || coverLetter,
    };
    const application = await appService.createApplication(normalized);
    return respond(res, { status: 'success', message: 'Lamaran berhasil dikirim', data: application }, 201);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getAllApplicationsHandler = async (req, res) => {
  try {
    const applications = await appService.getAllApplications();
    return respond(res, { status: 'success', data: { applications } }, 200);
  } catch (err) {
    return respond(res, { status: 'error', message: err.message }, 500);
  }
};

const getApplicationByIdHandler = async (req, res) => {
  try {
    const application = await appService.getApplicationById(req.params.id);
    return respond(res, { status: 'success', data: application }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getApplicationsByUserHandler = async (req, res) => {
  try {
    const applications = await appService.getApplicationsByUserId(req.params.userId);
    return respond(res, { status: 'success', data: { applications } }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getApplicationsByJobHandler = async (req, res) => {
  try {
    const applications = await appService.getApplicationsByJobId(req.params.jobId);
    return respond(res, { status: 'success', data: { applications } }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const updateApplicationHandler = async (req, res) => {
  try {
    const application = await appService.updateApplicationById(req.params.id, req.body);
    return respond(res, { status: 'success', message: 'Status lamaran berhasil diperbarui', data: application }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const deleteApplicationHandler = async (req, res) => {
  try {
    const { id: userId } = req.auth.credentials;
    await appService.verifyApplicationAccess(req.params.id, userId);
    await appService.deleteApplicationById(req.params.id);
    return respond(res, { status: 'success', message: 'Lamaran berhasil dihapus' }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

module.exports = {
  createApplicationHandler, getAllApplicationsHandler, getApplicationByIdHandler,
  getApplicationsByUserHandler, getApplicationsByJobHandler,
  updateApplicationHandler, deleteApplicationHandler,
};
