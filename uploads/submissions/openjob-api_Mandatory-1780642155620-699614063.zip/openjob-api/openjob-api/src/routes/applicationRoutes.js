const router = require('express').Router();

const auth = require('../middleware/auth');

const controller = require('../controllers/applicationController');

// SPECIFIC ROUTES FIRST
router.get('/user/:userId', auth, controller.getApplicationsByUser);

router.get('/job/:jobId', auth, controller.getApplicationsByJob);

// GENERAL
router.post('/', auth, controller.applyJob);

router.get('/', auth, controller.getApplications);

router.get('/:id', auth, controller.getApplicationById);

router.put('/:id', auth, controller.updateApplication);

router.delete('/:id', auth, controller.deleteApplication);

module.exports = router;