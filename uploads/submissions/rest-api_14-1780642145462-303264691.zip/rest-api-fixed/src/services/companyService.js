const pool = require('../db/pool');
const { randomBytes } = require('crypto');
const { NotFoundError, AuthorizationError } = require('../exceptions');

const createCompany = async ({ name, description, industry, location, website, logo_url, owner_id }) => {
  const id = `company-${randomBytes(12).toString('base64url')}`;
  const now = new Date().toISOString();
  const result = await pool.query({
    text: `INSERT INTO companies (id, name, description, industry, location, website, logo_url, owner_id, created_at, updated_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
           RETURNING *`,
    values: [id, name, description, industry, location, website, logo_url, owner_id, now, now],
  });
  return result.rows[0];
};

const getAllCompanies = async () => {
  const result = await pool.query('SELECT * FROM companies ORDER BY created_at DESC');
  return result.rows;
};

const getCompanyById = async (id) => {
  const result = await pool.query({ text: 'SELECT * FROM companies WHERE id = $1', values: [id] });
  if (result.rows.length === 0) {throw new NotFoundError(`Company dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const verifyCompanyOwner = async (companyId, userId) => {
  const result = await pool.query({ text: 'SELECT owner_id FROM companies WHERE id = $1', values: [companyId] });
  if (result.rows.length === 0) {throw new NotFoundError(`Company dengan id ${companyId} tidak ditemukan`);}
  if (result.rows[0].owner_id !== userId) {throw new AuthorizationError('Anda tidak berhak mengakses resource ini');}
};

const updateCompanyById = async (id, { name, description, industry, location, website, logo_url }) => {
  const fields = [];
  const values = [];
  let idx = 1;
  if (name !== undefined) { fields.push(`name = $${idx++}`); values.push(name); }
  if (description !== undefined) { fields.push(`description = $${idx++}`); values.push(description); }
  if (industry !== undefined) { fields.push(`industry = $${idx++}`); values.push(industry); }
  if (location !== undefined) { fields.push(`location = $${idx++}`); values.push(location); }
  if (website !== undefined) { fields.push(`website = $${idx++}`); values.push(website); }
  if (logo_url !== undefined) { fields.push(`logo_url = $${idx++}`); values.push(logo_url); }
  fields.push(`updated_at = $${idx++}`);
  values.push(new Date().toISOString());
  values.push(id);
  const result = await pool.query({
    text: `UPDATE companies SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`,
    values,
  });
  if (result.rows.length === 0) {throw new NotFoundError(`Company dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const deleteCompanyById = async (id) => {
  const result = await pool.query({ text: 'DELETE FROM companies WHERE id = $1 RETURNING id', values: [id] });
  if (result.rows.length === 0) {throw new NotFoundError(`Company dengan id ${id} tidak ditemukan`);}
};

module.exports = { createCompany, getAllCompanies, getCompanyById, verifyCompanyOwner, updateCompanyById, deleteCompanyById };
