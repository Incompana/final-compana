const jwt = require('jsonwebtoken');

const auth = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({
      status: 'failed',
      message: 'Missing authentication token',
    });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_KEY);

    console.log('DECODED TOKEN:', decoded);

    req.userId = decoded.id;

    next();
  } catch (err) {
    console.log(err);

    return res.status(401).json({
      status: 'failed',
      message: 'Invalid token',
    });
  }
};

module.exports = auth;