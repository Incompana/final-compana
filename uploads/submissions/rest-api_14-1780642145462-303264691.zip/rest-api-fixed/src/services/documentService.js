const pool = require('../db/pool');
const { randomBytes } = require('crypto');
const { NotFoundError, AuthorizationError } = require('../exceptions');
const fs = require('fs');
const path = require('path');

const createDocument = async ({ user_id, name, file_url, file_type, file_size }) => {
  const id = `doc-${randomBytes(12).toString('base64url')}`;
  const now = new Date().toISOString();
  const result = await pool.query({
    text: 'INSERT INTO documents (id, user_id, name, file_url, file_type, file_size, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *',
    values: [id, user_id, name, file_url, file_type, file_size, now],
  });
  return result.rows[0];
};

const getAllDocuments = async () => {
  const result = await pool.query('SELECT * FROM documents ORDER BY created_at DESC');
  return result.rows;
};

const getDocumentById = async (id) => {
  const result = await pool.query({ text: 'SELECT * FROM documents WHERE id = $1', values: [id] });
  if (result.rows.length === 0) {throw new NotFoundError(`Document dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const deleteDocumentById = async (id) => {
  const docResult = await pool.query({ text: 'SELECT * FROM documents WHERE id = $1', values: [id] });
  if (docResult.rows.length === 0) {throw new NotFoundError(`Document dengan id ${id} tidak ditemukan`);}

  const doc = docResult.rows[0];
  // Delete physical file if exists
  const filePath = path.join(__dirname, '../../uploads', path.basename(doc.file_url));
  if (fs.existsSync(filePath)) {fs.unlinkSync(filePath);}

  await pool.query({ text: 'DELETE FROM documents WHERE id = $1', values: [id] });
};

const verifyDocumentOwner = async (documentId, userId) => {
  const result = await pool.query({ text: 'SELECT user_id FROM documents WHERE id = $1', values: [documentId] });
  if (result.rows.length === 0) {throw new NotFoundError(`Document dengan id ${documentId} tidak ditemukan`);}
  if (result.rows[0].user_id !== userId) {throw new AuthorizationError('Anda tidak berhak mengakses resource ini');}
};

module.exports = { createDocument, getAllDocuments, getDocumentById, deleteDocumentById, verifyDocumentOwner };
