const pool = require('../db/pool');
const { ValidationError } = require('../exceptions');

const addRefreshToken = async (token) => {
  await pool.query({
    text: 'INSERT INTO authentications (token) VALUES ($1)',
    values: [token],
  });
};

const verifyRefreshToken = async (token) => {
  const result = await pool.query({
    text: 'SELECT token FROM authentications WHERE token = $1',
    values: [token],
  });
  if (result.rows.length === 0) {
    throw new ValidationError('Refresh token tidak valid');
  }
};

const deleteRefreshToken = async (token) => {
  await pool.query({
    text: 'DELETE FROM authentications WHERE token = $1',
    values: [token],
  });
};

module.exports = { addRefreshToken, verifyRefreshToken, deleteRefreshToken };
