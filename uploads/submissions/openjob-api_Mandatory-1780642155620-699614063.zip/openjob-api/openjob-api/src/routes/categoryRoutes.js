const express = require('express');
const router = express.Router();

const auth = require('../middleware/auth');
const validate = require('../middleware/validate');
const categorySchema = require('../validations/categoryValidation');

const {
  createCategoryHandler,
  getCategoriesHandler,
  getCategoryByIdHandler,
  updateCategoryHandler,
  deleteCategoryHandler,
} = require('../controllers/categoryController');

// CREATE
router.post('/', auth, validate(categorySchema), createCategoryHandler);

// GET ALL
router.get('/', getCategoriesHandler);

// GET BY ID
router.get('/:id', getCategoryByIdHandler);

// UPDATE
router.put('/:id', auth, validate(categorySchema), updateCategoryHandler);

// DELETE
router.delete('/:id', auth, deleteCategoryHandler);

module.exports = router;