exports.up = (pgm) => {
  pgm.createTable('categories', {

    id: {
      type: 'UUID',
      primaryKey: true,
      default: pgm.func('gen_random_uuid()'),
    },

    name: {
      type: 'VARCHAR(100)',
      notNull: true,
    },

    created_at: {
      type: 'TIMESTAMP',
      notNull: true,
      default: pgm.func('current_timestamp'),
    },

    updated_at: {
      type: 'TIMESTAMP',
      notNull: true,
      default: pgm.func('current_timestamp'),
    },

  });
};

exports.down = (pgm) => {
  pgm.dropTable('categories');
};