const service = require('../services/categoryService');

// helper
const success = (res, data, code = 200) =>
  res.status(code).json({ status: 'success', data });

const failed = (res, message, code = 400) =>
  res.status(code).json({ status: 'failed', message });

// VALIDASI UUID
const isUUID = (id) => {
  const uuidRegex =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

  return uuidRegex.test(id);
};

// CREATE
const createCategoryHandler = async (req, res) => {
  try {
    const category = await service.addCategory(req.body);

    return success(res, { id: category.id }, 201);
  } catch (err) {
    return failed(res, err.message);
  }
};

// GET ALL
const getCategoriesHandler = async (req, res) => {
  try {
    const categories = await service.getCategories();

    return success(res, { categories });
  } catch (err) {
    return failed(res, err.message);
  }
};

// GET BY ID
const getCategoryByIdHandler = async (req, res) => {
  try {
    const { id } = req.params;

    // FIX INVALID UUID
    if (!isUUID(id)) {
      return failed(res, 'Category not found', 404);
    }

    const category = await service.getCategoryById(id);

    if (!category) {
      return failed(res, 'Category not found', 404);
    }

    return success(res, category);
  } catch (err) {
    return failed(res, err.message);
  }
};

// UPDATE
const updateCategoryHandler = async (req, res) => {
  try {
    const { id } = req.params;

    // FIX INVALID UUID
    if (!isUUID(id)) {
      return failed(res, 'Category not found', 404);
    }

    const category = await service.updateCategory(id, req.body);

    if (!category) {
      return failed(res, 'Category not found', 404);
    }

    return res.status(200).json({
      status: 'success',
      message: 'Category updated successfully',
      data: category,
    });
  } catch (err) {
    return failed(res, err.message);
  }
};

// DELETE
const deleteCategoryHandler = async (req, res) => {
  try {
    const { id } = req.params;

    // FIX INVALID UUID
    if (!isUUID(id)) {
      return failed(res, 'Category not found', 404);
    }

    const category = await service.deleteCategory(id);

    if (!category) {
      return failed(res, 'Category not found', 404);
    }

    return res.status(200).json({
      status: 'success',
      message: 'Category deleted successfully',
    });
  } catch (err) {
    return failed(res, err.message);
  }
};

module.exports = {
  createCategoryHandler,
  getCategoriesHandler,
  getCategoryByIdHandler,
  updateCategoryHandler,
  deleteCategoryHandler,
};