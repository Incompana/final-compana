const express = require('express');
const multer = require('multer');

const router = express.Router();

const auth = require('../middleware/auth');
const upload = require('../middleware/upload');
const controller = require('../controllers/documentController');

router.post('/', auth, (req, res) => {

  upload.single('document')(req, res, async (err) => {

    if (err instanceof multer.MulterError) {
  return res.status(400).json({
    status: 'failed',
    message: err.message,
  });
}

if (err) {
  return res.status(400).json({
    status: 'failed',
    message: err.message,
  });
}

if (!req.file) {
  return res.status(400).json({
    status: 'failed',
    message: 'File is required',
  });
}
    // lanjut ke controller
    return controller.uploadDocument(req, res);
  });
});

router.get('/', controller.getDocuments);

router.get('/:id', controller.getDocumentById);

router.delete('/:id', auth, controller.deleteDocument);

module.exports = router;