const userService = require('../services/userService');
const appService = require('../services/applicationService');
const bookmarkService = require('../services/bookmarkService');

const respond = (res, { status, message, data }, code) => {
  const body = { status, ...(message && { message }), ...(data && { data }) };
  return res.status(code).json(body);
};

const getProfileHandler = async (req, res) => {
  try {
    const { id } = req.auth.credentials;
    const user = await userService.getUserById(id);
    return respond(res, { status: 'success', data: user }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getMyApplicationsHandler = async (req, res) => {
  try {
    const { id } = req.auth.credentials;
    const applications = await appService.getApplicationsByUserId(id);
    return respond(res, { status: 'success', data: { applications } }, 200);
  } catch (err) {
    return respond(res, { status: 'error', message: err.message }, 500);
  }
};

const getMyBookmarksHandler = async (req, res) => {
  try {
    const { id } = req.auth.credentials;
    const bookmarks = await bookmarkService.getAllBookmarksByUserId(id);
    return respond(res, { status: 'success', data: { bookmarks } }, 200);
  } catch (err) {
    return respond(res, { status: 'error', message: err.message }, 500);
  }
};

module.exports = { getProfileHandler, getMyApplicationsHandler, getMyBookmarksHandler };
