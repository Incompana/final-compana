const Joi = require('joi');
const { ValidationError } = require('../exceptions');

const LoginPayloadSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
}).unknown(false);

const RefreshTokenSchema = Joi.object({
  refreshToken: Joi.string().required(),
}).unknown(false);

const validateLoginPayload = (payload) => {
  const { error, value } = LoginPayloadSchema.validate(payload, { abortEarly: false });
  if (error) { throw new ValidationError(error.message); }
  return value;
};

const validateRefreshToken = (payload) => {
  const { error, value } = RefreshTokenSchema.validate(payload, { abortEarly: false });
  if (error) { throw new ValidationError(error.message); }
  return value;
};

module.exports = { validateLoginPayload, validateRefreshToken };
