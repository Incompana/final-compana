const amqp = require('amqplib');

const publishMessage = async (queue, message) => {
  try {
    const connection = await amqp.connect(
      process.env.AMQP_URL
    );

    const channel = await connection.createChannel();

    await channel.assertQueue(queue, {
      durable: true,
    });

    channel.sendToQueue(
      queue,
      Buffer.from(JSON.stringify(message))
    );

    console.log('Message published');

    setTimeout(() => {
      connection.close();
    }, 500);

  } catch (error) {
    console.log(error);
  }
};

module.exports = publishMessage;