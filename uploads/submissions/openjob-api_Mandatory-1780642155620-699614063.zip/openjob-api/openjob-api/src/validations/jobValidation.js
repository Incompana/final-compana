// src/validations/jobValidation.js

const Joi = require('joi');

const jobSchema = Joi.object({
  company_id: Joi.string().required(),

  category_id: Joi.string().required(),

  title: Joi.string().required(),

  description: Joi.string().required(),

  job_type: Joi.string()
    .valid('full-time', 'part-time', 'contract', 'internship')
    .required(),

  experience_level: Joi.string()
    .valid('junior', 'mid', 'senior')
    .required(),

  location_type: Joi.string()
    .valid('onsite', 'remote', 'hybrid')
    .required(),

  // OPTIONAL
  location_city: Joi.string().allow('', null),

  // OPTIONAL
  salary_min: Joi.number().allow(null),

  // OPTIONAL
  salary_max: Joi.number().allow(null),

  is_salary_visible: Joi.boolean().default(true),

  status: Joi.string()
    .valid('open', 'closed')
    .default('open'),
});

module.exports = jobSchema;