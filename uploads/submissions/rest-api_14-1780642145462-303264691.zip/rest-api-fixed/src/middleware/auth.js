const TokenManager = require('../tokenize/TokenManager');

const authenticate = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ status: 'failed', message: 'Missing authentication' });
  }

  const token = authHeader.slice(7);
  try {
    const payload = TokenManager.verifyAccessToken(token);
    req.auth = { credentials: { id: payload.id } };
    return next();
  } catch (_err) {
    return res.status(401).json({ status: 'failed', message: 'Missing authentication' });
  }
};

module.exports = { authenticate };
