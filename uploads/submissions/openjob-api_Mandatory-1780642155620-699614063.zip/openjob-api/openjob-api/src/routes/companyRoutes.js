const express = require('express');
const router = express.Router();

const controller = require('../controllers/companyController');
const auth = require('../middleware/auth');

// public
router.get('/', controller.getCompanies);
router.get('/:id', controller.getCompanyById);

// protected
router.post('/', auth, controller.createCompany);
router.put('/:id', auth, controller.updateCompany);
router.delete('/:id', auth, controller.deleteCompany);

module.exports = router;