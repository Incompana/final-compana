const pool = require('../db/pool');
const { randomBytes } = require('crypto');
const { NotFoundError, AuthorizationError, ValidationError } = require('../exceptions');

const createJob = async ({ title, description, requirements, location, type, salary_min, salary_max, company_id, category_id }) => {
  const companyCheck = await pool.query({ text: 'SELECT owner_id FROM companies WHERE id = $1', values: [company_id] });
  if (companyCheck.rows.length === 0) {
    throw new ValidationError('company_id tidak valid atau tidak ditemukan');
  }

  if (category_id !== undefined && category_id !== null && category_id !== '') {
    const categoryCheck = await pool.query({ text: 'SELECT id FROM categories WHERE id = $1', values: [category_id] });
    if (categoryCheck.rows.length === 0) {
      throw new ValidationError('category_id tidak valid atau tidak ditemukan');
    }
  }

  const id = `job-${randomBytes(12).toString('base64url')}`;
  const now = new Date().toISOString();
  const result = await pool.query({
    text: `INSERT INTO jobs (id, title, description, requirements, location, type, salary_min, salary_max, company_id, category_id, created_at, updated_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    values: [id, title, description, requirements, location, type, salary_min, salary_max, company_id, category_id, now, now],
  });
  return result.rows[0];
};

const getAllJobs = async ({ title, companyName } = {}) => {
  const whereClauses = [];
  const values = [];

  if (title) {
    values.push(`%${title}%`);
    whereClauses.push(`j.title ILIKE $${values.length}`);
  }
  if (companyName) {
    values.push(`%${companyName}%`);
    whereClauses.push(`c.name ILIKE $${values.length}`);
  }

  const whereSQL = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
  const query = `
    SELECT j.*, c.name as company_name, cat.name as category_name
    FROM jobs j
    LEFT JOIN companies c ON j.company_id = c.id
    LEFT JOIN categories cat ON j.category_id = cat.id
    ${whereSQL}
    ORDER BY j.created_at DESC
  `;

  const result = await pool.query({ text: query, values });
  return result.rows;
};

const getJobById = async (id) => {
  const result = await pool.query({
    text: `SELECT j.*, c.name as company_name, cat.name as category_name
           FROM jobs j
           LEFT JOIN companies c ON j.company_id = c.id
           LEFT JOIN categories cat ON j.category_id = cat.id
           WHERE j.id = $1`,
    values: [id],
  });
  if (result.rows.length === 0) {throw new NotFoundError(`Job dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const getJobsByCompanyId = async (companyId) => {
  const result = await pool.query({
    text: `SELECT j.*, c.name as company_name, cat.name as category_name
           FROM jobs j
           LEFT JOIN companies c ON j.company_id = c.id
           LEFT JOIN categories cat ON j.category_id = cat.id
           WHERE j.company_id = $1 ORDER BY j.created_at DESC`,
    values: [companyId],
  });
  return result.rows;
};

const getJobsByCategoryId = async (categoryId) => {
  const result = await pool.query({
    text: `SELECT j.*, c.name as company_name, cat.name as category_name
           FROM jobs j
           LEFT JOIN companies c ON j.company_id = c.id
           LEFT JOIN categories cat ON j.category_id = cat.id
           WHERE j.category_id = $1 ORDER BY j.created_at DESC`,
    values: [categoryId],
  });
  return result.rows;
};

const verifyJobOwner = async (jobId, userId) => {
  const result = await pool.query({
    text: 'SELECT c.owner_id FROM jobs j JOIN companies c ON j.company_id = c.id WHERE j.id = $1',
    values: [jobId],
  });
  if (result.rows.length === 0) {throw new NotFoundError(`Job dengan id ${jobId} tidak ditemukan`);}
  if (result.rows[0].owner_id !== userId) {throw new AuthorizationError('Anda tidak berhak mengakses resource ini');}
};

const updateJobById = async (id, { title, description, requirements, location, type, salary_min, salary_max, category_id }) => {
  const fields = [];
  const values = [];
  let idx = 1;
  if (title !== undefined) { fields.push(`title = $${idx++}`); values.push(title); }
  if (description !== undefined) { fields.push(`description = $${idx++}`); values.push(description); }
  if (requirements !== undefined) { fields.push(`requirements = $${idx++}`); values.push(requirements); }
  if (location !== undefined) { fields.push(`location = $${idx++}`); values.push(location); }
  if (type !== undefined) { fields.push(`type = $${idx++}`); values.push(type); }
  if (salary_min !== undefined) { fields.push(`salary_min = $${idx++}`); values.push(salary_min); }
  if (salary_max !== undefined) { fields.push(`salary_max = $${idx++}`); values.push(salary_max); }
  if (category_id !== undefined) { fields.push(`category_id = $${idx++}`); values.push(category_id); }
  fields.push(`updated_at = $${idx++}`);
  values.push(new Date().toISOString());
  values.push(id);
  const result = await pool.query({
    text: `UPDATE jobs SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`,
    values,
  });
  if (result.rows.length === 0) {throw new NotFoundError(`Job dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const deleteJobById = async (id) => {
  const result = await pool.query({ text: 'DELETE FROM jobs WHERE id = $1 RETURNING id', values: [id] });
  if (result.rows.length === 0) {throw new NotFoundError(`Job dengan id ${id} tidak ditemukan`);}
};

module.exports = { createJob, getAllJobs, getJobById, getJobsByCompanyId, getJobsByCategoryId, verifyJobOwner, updateJobById, deleteJobById };
