const pool = require('../config/database');
const { nanoid } = require('nanoid');

// CREATE
const createCompany = async ({
  name,
  description,
  location,
  owner_id,
}) => {
  const id = `company-${nanoid(16)}`;

  const result = await pool.query(
    `
    INSERT INTO companies (
      id,
      owner_id,
      name,
      description,
      location,
      created_at,
      updated_at
    )
    VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
    RETURNING id, owner_id, name, description, location, created_at
    `,
    [id, owner_id, name, description, location]
  );

  return result.rows[0];
};

// GET ALL (🔥 FIX FINAL)
const getCompanies = async () => {
  const result = await pool.query(`
    SELECT 
      id,
      owner_id,
      name,
      description,
      location,
      created_at
    FROM companies
    ORDER BY created_at DESC
  `);

  return result.rows.map((row) => ({
    id: row.id,
    owner_id: row.owner_id,
    name: row.name,
    description: row.description,
    location: row.location,
    created_at: row.created_at,
  }));
};

// GET BY ID
const getCompanyById = async (id) => {
  const result = await pool.query(
    `
    SELECT 
      id,
      owner_id,
      name,
      description,
      location,
      created_at
    FROM companies
    WHERE id = $1
    `,
    [id]
  );

  if (!result.rows.length) {
    const error = new Error('Company not found');
    error.statusCode = 404;
    throw error;
  }

  const c = result.rows[0];

  return {
    id: c.id,
    owner_id: c.owner_id,
    name: c.name,
    description: c.description,
    location: c.location,
    created_at: c.created_at,
  };
};

// UPDATE
const updateCompany = async (id, { name, description, location }) => {
  const result = await pool.query(
    `
    UPDATE companies
    SET name = $1,
        description = $2,
        location = $3,
        updated_at = NOW()
    WHERE id = $4
    RETURNING id, owner_id, name, description, location, created_at
    `,
    [name, description, location, id]
  );

  if (!result.rows.length) {
    const error = new Error('Company not found');
    error.statusCode = 404;
    throw error;
  }

  return result.rows[0];
};

// DELETE
const deleteCompany = async (id) => {
  const result = await pool.query(
    `
    DELETE FROM companies
    WHERE id = $1
    RETURNING id, owner_id, name, description, location, created_at
    `,
    [id]
  );

  if (!result.rows.length) {
    const error = new Error('Company not found');
    error.statusCode = 404;
    throw error;
  }

  return result.rows[0];
};

module.exports = {
  createCompany,
  getCompanies,
  getCompanyById,
  updateCompany,
  deleteCompany,
};