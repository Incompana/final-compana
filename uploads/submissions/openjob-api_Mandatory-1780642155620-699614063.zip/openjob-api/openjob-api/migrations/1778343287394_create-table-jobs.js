exports.up = (pgm) => {

  pgm.createTable('jobs', {

    id: {
      type: 'VARCHAR(50)',
      primaryKey: true,
    },

    company_id: {
      type: 'VARCHAR(50)',
      notNull: true,
      references: 'companies(id)',
      onDelete: 'CASCADE',
    },

    category_id: {
      type: 'UUID',
      notNull: true,
      references: 'categories(id)',
      onDelete: 'CASCADE',
    },

    title: {
      type: 'VARCHAR(150)',
      notNull: true,
    },

    description: {
      type: 'TEXT',
      notNull: true,
    },

    job_type: {
      type: 'VARCHAR(50)',
      notNull: true,
    },

    experience_level: {
      type: 'VARCHAR(50)',
      notNull: true,
    },

    location_type: {
      type: 'VARCHAR(50)',
      notNull: true,
    },

    location_city: {
      type: 'VARCHAR(100)',
      notNull: false,
    },

    salary_min: {
      type: 'INTEGER',
      notNull: true,
    },

    salary_max: {
      type: 'INTEGER',
      notNull: true,
    },

    is_salary_visible: {
      type: 'BOOLEAN',
      default: true,
    },

    status: {
      type: 'VARCHAR(20)',
      default: 'open',
    },

    created_at: {
      type: 'TIMESTAMP',
      default: pgm.func('current_timestamp'),
    },

    updated_at: {
      type: 'TIMESTAMP',
      default: pgm.func('current_timestamp'),
    },

  });

};

exports.down = (pgm) => {
  pgm.dropTable('jobs');
};