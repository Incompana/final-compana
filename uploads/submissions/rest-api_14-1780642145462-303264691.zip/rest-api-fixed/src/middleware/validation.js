const validationMiddleware = (validateFn) => (req, res, next) => {
  try {
    const validated = validateFn(req.body);
    if (validated !== undefined) {
      req.body = validated;
    }
    next();
  } catch (err) {
    next(err);
  }
};

module.exports = { validationMiddleware };
