const pool = require('../db/pool');
const { randomBytes } = require('crypto');
const { NotFoundError, AuthorizationError, ConflictError } = require('../exceptions');

const createBookmark = async ({ user_id, job_id }) => {
  const check = await pool.query({
    text: 'SELECT id FROM bookmarks WHERE user_id = $1 AND job_id = $2',
    values: [user_id, job_id],
  });
  if (check.rows.length > 0) {throw new ConflictError('Job sudah di-bookmark');}

  const id = `bookmark-${randomBytes(12).toString('base64url')}`;
  const now = new Date().toISOString();
  const result = await pool.query({
    text: 'INSERT INTO bookmarks (id, user_id, job_id, created_at) VALUES ($1,$2,$3,$4) RETURNING *',
    values: [id, user_id, job_id, now],
  });
  return result.rows[0];
};

const getBookmarkById = async (id) => {
  const result = await pool.query({
    text: `SELECT b.*, j.title as job_title, c.name as company_name
           FROM bookmarks b
           JOIN jobs j ON b.job_id = j.id
           JOIN companies c ON j.company_id = c.id
           WHERE b.id = $1`,
    values: [id],
  });
  if (result.rows.length === 0) {throw new NotFoundError(`Bookmark dengan id ${id} tidak ditemukan`);}
  return result.rows[0];
};

const getAllBookmarksByUserId = async (userId) => {
  const result = await pool.query({
    text: `SELECT b.*, j.title as job_title, c.name as company_name
           FROM bookmarks b
           JOIN jobs j ON b.job_id = j.id
           JOIN companies c ON j.company_id = c.id
           WHERE b.user_id = $1 ORDER BY b.created_at DESC`,
    values: [userId],
  });
  return result.rows;
};

const deleteBookmarkByUserAndJob = async ({ user_id, job_id }) => {
  const result = await pool.query({
    text: 'DELETE FROM bookmarks WHERE user_id = $1 AND job_id = $2 RETURNING id',
    values: [user_id, job_id],
  });
  if (result.rows.length === 0) {throw new NotFoundError('Bookmark tidak ditemukan');}
};

const verifyBookmarkOwner = async (bookmarkId, userId) => {
  const result = await pool.query({ text: 'SELECT user_id FROM bookmarks WHERE id = $1', values: [bookmarkId] });
  if (result.rows.length === 0) {throw new NotFoundError(`Bookmark dengan id ${bookmarkId} tidak ditemukan`);}
  if (result.rows[0].user_id !== userId) {throw new AuthorizationError('Anda tidak berhak mengakses resource ini');}
};

module.exports = { createBookmark, getBookmarkById, getAllBookmarksByUserId, deleteBookmarkByUserAndJob, verifyBookmarkOwner };
