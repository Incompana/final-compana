const redis = require('redis');

const client = redis.createClient({
  socket: {
    host: process.env.REDIS_HOST,
    port: process.env.REDIS_PORT,
  },
});

client.on('error', (err) => {
  console.log('Redis Error:', err);
});

let connected = false;

(async () => {
  if (!connected) {
    await client.connect();
    connected = true;
    console.log('Redis Connected');
  }
})();

const RedisService = {
  async get(key) {
    return await client.get(key);
  },

  async set(key, value, expiration = 3600) {
    await client.set(key, value, {
      EX: expiration,
    });
  },

  async del(key) {
    return await client.del(key);
  },
};

module.exports = RedisService;