const service = require('../services/bookmarkService');
const RedisService = require('../services/redisService');

const success = (res, data, code = 200) => {
  return res.status(code).json({
    status: 'success',
    data,
  });
};

const failed = (res, message, code = 400) => {
  return res.status(code).json({
    status: 'failed',
    message,
  });
};

// ======================
// GET ALL BOOKMARKS (FIX FINAL 18 FIELDS)
// ======================
const getBookmarks = async (req, res) => {
  try {
    const userId = req.userId;
    const cacheKey = `bookmarks:${userId}`;

    const cached = await RedisService.get(cacheKey);

    if (cached) {
      res.set('X-Data-Source', 'cache');

      return res.status(200).json({
        status: 'success',
        data: {
          bookmarks: JSON.parse(cached),
        },
      });
    }

    const bookmarks = await service.getBookmarks(userId);

    await RedisService.set(cacheKey, JSON.stringify(bookmarks), 3600);

    res.set('X-Data-Source', 'database');

    return res.status(200).json({
      status: 'success',
      data: {
        bookmarks,
      },
    });

  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};
// ======================
// POST BOOKMARK
// ======================
const postBookmark = async (req, res) => {
  try {
    const userId = req.userId;
    const jobId = req.params.jobId;

    const bookmark = await service.addBookmark(userId, jobId);

    await RedisService.del(`bookmarks:${userId}`);

    return success(res, { id: bookmark.id }, 201);
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

// ======================
// DELETE BOOKMARK
// ======================
const deleteBookmark = async (req, res) => {
  try {
    const userId = req.userId;
    const jobId = req.params.jobId;

    const bookmark = await service.deleteBookmark(userId, jobId);

    if (!bookmark) {
      return failed(res, 'Bookmark not found', 404);
    }

    await RedisService.del(`bookmarks:${userId}`);

    return success(res, {
      message: 'Bookmark deleted',
    });
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

// ======================
// GET BOOKMARK BY ID
// ======================
const getBookmarkById = async (req, res) => {
  try {
    const bookmark = await service.getBookmarkById(req.params.bookmarkId);

    if (!bookmark) {
      return failed(res, 'Bookmark not found', 404);
    }

    return success(res, bookmark);
  } catch (err) {
    console.log(err);
    return failed(res, err.message, 500);
  }
};

module.exports = {
  getBookmarks,
  postBookmark,
  deleteBookmark,
  getBookmarkById,
};