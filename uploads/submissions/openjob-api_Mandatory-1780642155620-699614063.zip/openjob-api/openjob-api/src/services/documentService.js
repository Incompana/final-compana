const pool = require('../config/database');
const { nanoid } = require('nanoid');

const addDocument = async (
  userId,
  filename,
  filepath,
  originalName,
  size
) => {
  const id = `document-${nanoid(16)}`;

  const result = await pool.query(
    `
    INSERT INTO documents (
      id,
      user_id,
      filename,
      filepath,
      original_name,
      size
    )
    VALUES ($1,$2,$3,$4,$5,$6)
    RETURNING *
    `,
    [id, userId, filename, filepath, originalName, size]
  );

  return result.rows[0];
};

const getDocuments = async () => {
  const result = await pool.query(`SELECT * FROM documents`);
  return result.rows;
};

const getDocumentById = async (id) => {
  const result = await pool.query(
    `SELECT * FROM documents WHERE id = $1`,
    [id]
  );

  return result.rows[0];
};

const deleteDocument = async (id) => {
  const result = await pool.query(
    `DELETE FROM documents WHERE id = $1 RETURNING *`,
    [id]
  );

  return result.rows[0];
};

module.exports = {
  addDocument,
  getDocuments,
  getDocumentById,
  deleteDocument,
};