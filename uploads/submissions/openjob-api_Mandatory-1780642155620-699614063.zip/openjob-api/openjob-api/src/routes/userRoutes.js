const express = require('express');
const router = express.Router();

const validate = require('../middleware/validate');
const userSchema = require('../validations/userValidation');

const RedisService = require('../services/redisService');

const {
  addUser,
  getUsers,
  getUserById,
} = require('../services/userService');

// CREATE USER
router.post('/', validate(userSchema), async (req, res, next) => {
  try {
    const addedUser = await addUser(req.body);

    return res.status(201).json({
      status: 'success',
      data: {
        id: addedUser.id,
        name: addedUser.name,
        email: addedUser.email,
      },
    });

  } catch (err) {
    next(err);
  }
});

// GET ALL USERS
router.get('/', async (req, res, next) => {
  try {
    const users = await getUsers();

    return res.json({
      status: 'success',
      data: {
        users,
      },
    });

  } catch (err) {
    next(err);
  }
});

// GET USER BY ID + CACHE
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    const cacheKey = `user:${id}`;

    // CEK CACHE
    const cachedData = await RedisService.get(cacheKey);

    // CACHE HIT
    if (cachedData) {
      return res
        .header('X-Data-Source', 'cache')
        .json({
          status: 'success',
          data: JSON.parse(cachedData),
        });
    }

    // DATABASE
    const user = await getUserById(id);

    // SAVE CACHE
    await RedisService.set(
      cacheKey,
      JSON.stringify(user),
      3600
    );

    return res
      .header('X-Data-Source', 'database')
      .json({
        status: 'success',
        data: user,
      });

  } catch (err) {
    next(err);
  }
});

module.exports = router;