const categoryService = require('../services/categoryService');

const respond = (res, { status, message, data }, code) => {
  const body = { status, ...(message && { message }), ...(data && { data }) };
  return res.status(code).json(body);
};

const createCategoryHandler = async (req, res) => {
  try {
    const category = await categoryService.createCategory(req.body);
    return respond(res, { status: 'success', message: 'Category berhasil ditambahkan', data: category }, 201);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const getAllCategoriesHandler = async (req, res) => {
  try {
    const categories = await categoryService.getAllCategories();
    return respond(res, { status: 'success', data: { categories } }, 200);
  } catch (err) {
    return respond(res, { status: 'error', message: err.message }, 500);
  }
};

const getCategoryByIdHandler = async (req, res) => {
  try {
    const category = await categoryService.getCategoryById(req.params.id);
    return respond(res, { status: 'success', data: category }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const updateCategoryHandler = async (req, res) => {
  try {
    const category = await categoryService.updateCategoryById(req.params.id, req.body);
    return respond(res, { status: 'success', message: 'Category berhasil diperbarui', data: category }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

const deleteCategoryHandler = async (req, res) => {
  try {
    await categoryService.deleteCategoryById(req.params.id);
    return respond(res, { status: 'success', message: 'Category berhasil dihapus' }, 200);
  } catch (err) {
    const code = err.statusCode || 500;
    return respond(res, { status: code >= 500 ? 'error' : 'failed', message: err.message }, code);
  }
};

module.exports = { createCategoryHandler, getAllCategoriesHandler, getCategoryByIdHandler, updateCategoryHandler, deleteCategoryHandler };
