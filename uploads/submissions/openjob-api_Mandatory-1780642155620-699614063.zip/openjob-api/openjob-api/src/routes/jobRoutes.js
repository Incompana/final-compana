const router = require('express').Router();

const controller = require('../controllers/jobController');

const bookmarkController = require('../controllers/bookmarkController');

const auth = require('../middleware/auth');

router.post(
  '/:jobId/bookmark',
  auth,
  bookmarkController.postBookmark
);

router.delete(
  '/:jobId/bookmark',
  auth,
  bookmarkController.deleteBookmark
);

router.get(
  '/:jobId/bookmark/:bookmarkId',
  auth,
  bookmarkController.getBookmarkById
);
// company/category
router.get('/company/:id', controller.getByCompany);

router.get('/category/:id', controller.getByCategory);

// general
router.get('/', controller.getJobs);

router.get('/:id', controller.getJobById);

// protected
router.post('/', auth, controller.postJob);

router.put('/:id', auth, controller.putJob);

router.delete('/:id', auth, controller.deleteJob);

module.exports = router;