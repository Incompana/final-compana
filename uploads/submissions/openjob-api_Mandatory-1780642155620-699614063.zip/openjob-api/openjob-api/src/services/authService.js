const pool = require('../config/database');
const bcrypt = require('bcrypt');

// VERIFY USER
const verifyUser = async (email, password) => {
  const result = await pool.query(
    `SELECT * FROM users WHERE email = $1`,
    [email]
  );

  const user = result.rows[0];

  if (!user) {
    const error = new Error('Invalid credentials');
    error.statusCode = 401;
    throw error;
  }

  const match = await bcrypt.compare(password, user.password);

  if (!match) {
    const error = new Error('Invalid credentials');
    error.statusCode = 401;
    throw error;
  }

  return user;
};

// ADD REFRESH TOKEN
const addRefreshToken = async (token) => {
  const id = `auth-${Date.now()}`;

  await pool.query(
    `INSERT INTO authentications (id, token)
     VALUES ($1, $2)`,
    [id, token]
  );
};

// CHECK REFRESH TOKEN
const checkRefreshToken = async (token) => {
  const result = await pool.query(
    `SELECT token FROM authentications WHERE token = $1`,
    [token]
  );

  return result.rows.length > 0;
};

// DELETE REFRESH TOKEN
const deleteRefreshToken = async (token) => {
  await pool.query(
    `DELETE FROM authentications WHERE token = $1`,
    [token]
  );
};

module.exports = {
  verifyUser,
  addRefreshToken,
  checkRefreshToken,
  deleteRefreshToken,
};